"""
Agentic RAG-Based College Assistant - Streamlit Web Application.
Provides two dedicated interfaces:
1. Student Chatbot: Conversational AI with Agent Routing and Source Citations.
2. Admin Panel: Document Ingestion, Knowledge Base Management, and SQLite Inspection.
"""

import sys
import uuid
from pathlib import Path
import streamlit as st

# Ensure project root is in sys.path
PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.config import Config
from src.agent.agent_service import CollegeAgentService
from src.admin.admin_service import AdminService
from src.database.crud import seed_database_if_empty
from src.database.db import get_table_counts
from src.utils.helpers import format_file_size, format_latency
from src.utils.logger import get_logger

logger = get_logger("StreamlitApp")

# ==============================================================================
# PAGE CONFIGURATION & STYLING
# ==============================================================================

st.set_page_config(
    page_title="Apex University - Agentic College Assistant",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS styling for modern university portal look
st.markdown(
    """
    <style>
    .main-header {
        background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 60%, #0284c7 100%);
        padding: 22px 28px;
        border-radius: 12px;
        color: white;
        margin-bottom: 20px;
    }
    .main-title {
        font-size: 1.8rem;
        font-weight: 700;
        margin-bottom: 4px;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .main-subtitle {
        font-size: 0.95rem;
        color: #e0f2fe;
    }
    .tool-badge {
        display: inline-block;
        background-color: #dbeafe;
        color: #1e40af;
        border: 1px solid #bfdbfe;
        border-radius: 16px;
        padding: 3px 10px;
        font-size: 0.78rem;
        font-weight: 600;
        margin-bottom: 8px;
    }
    .citation-card {
        background-color: #f8fafc;
        border-left: 4px solid #3b82f6;
        border-radius: 6px;
        padding: 10px 14px;
        margin-top: 6px;
        margin-bottom: 6px;
        font-size: 0.88rem;
    }
    .citation-title {
        font-weight: 600;
        color: #0f172a;
    }
    .citation-snippet {
        color: #475569;
        font-style: italic;
        margin-top: 3px;
    }
    </style>
    """,
    unsafe_allow_html=True
)

# ==============================================================================
# INITIALIZE SERVICES IN STREAMLIT SESSION STATE
# ==============================================================================

if "agent_service" not in st.session_state:
    # Ensure SQLite is initialized and seeded
    seed_database_if_empty()
    st.session_state.agent_service = CollegeAgentService()

if "admin_service" not in st.session_state:
    st.session_state.admin_service = AdminService()

if "session_id" not in st.session_state:
    st.session_state.session_id = f"session_{uuid.uuid4().hex[:8]}"

if "chat_messages" not in st.session_state:
    st.session_state.chat_messages = []


# ==============================================================================
# SIDEBAR: NAVIGATION & SYSTEM STATUS
# ==============================================================================

with st.sidebar:
    st.markdown("### 🏛️ Apex University")
    st.caption("Agentic RAG Assistant & Knowledge Base")
    st.markdown("---")

    # Navigation Radio
    selected_page = st.radio(
        "Navigation",
        ["🧑‍🎓 Student Chatbot", "🛠️ Admin Panel"],
        index=0
    )

    st.markdown("---")
    st.markdown("#### ⚡ System Status")
    
    # Vector store count
    kb_stats = st.session_state.admin_service.vector_store.get_stats()
    db_counts = get_table_counts()

    st.write(f"📚 **ChromaDB Chunks:** `{kb_stats.get('total_chunks', 0)}`")
    st.write(f"📄 **Indexed Documents:** `{kb_stats.get('total_documents', 0)}`")
    st.write(f"👥 **Faculty Records:** `{db_counts.get('faculty', 0)}`")
    st.write(f"📅 **Class Schedules:** `{db_counts.get('class_timetables', 0)}`")
    st.write(f"📝 **Exam Schedules:** `{db_counts.get('exam_timetables', 0)}`")

    st.markdown("---")
    if st.button("🔄 Start New Conversation", use_container_width=True):
        st.session_state.session_id = f"session_{uuid.uuid4().hex[:8]}"
        st.session_state.chat_messages = []
        st.rerun()


# ==============================================================================
# PAGE 1: STUDENT CHATBOT
# ==============================================================================

if selected_page == "🧑‍🎓 Student Chatbot":
    # Hero Banner
    st.markdown(
        """
        <div class="main-header">
            <div class="main-title">
                <span>🎓</span> College Information Assistant
            </div>
            <div class="main-subtitle">
                Autonomous Agentic RAG • Intelligent Tool Routing • Verified Source Citations
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )

    # Quick Inquiry Suggestion Chips
    st.markdown("**Sample Student Questions:**")
    quick_prompts = [
        "What is Monday's class timetable for CSE 3rd semester?",
        "When is the examination for Database Management Systems?",
        "Who is the HOD of Computer Science and their email?",
        "What is the minimum attendance requirement and detention policy?",
        "What are the tuition fees and merit scholarships?"
    ]

    cols = st.columns(len(quick_prompts))
    selected_prompt = None
    labels = ["📅 Class Schedule", "📝 Exam Dates", "👥 Faculty / HOD", "📋 Attendance 75%", "💰 Fees & Aid"]

    for idx, prompt in enumerate(quick_prompts):
        with cols[idx]:
            if st.button(labels[idx], key=f"btn_p_{idx}", use_container_width=True):
                selected_prompt = prompt

    st.markdown("---")

    # Render Conversation History
    for msg in st.session_state.chat_messages:
        role = msg.get("role", "user")
        avatar = "🧑‍🎓" if role == "user" else "🎓"

        with st.chat_message(role, avatar=avatar):
            if role == "assistant":
                tool_used = msg.get("tool_used", "")
                latency = msg.get("latency", "")
                if tool_used:
                    st.markdown(
                        f"<span class='tool-badge'>🎯 Routed to: {tool_used} ({latency})</span>",
                        unsafe_allow_html=True
                    )

            st.markdown(msg.get("content", ""))

            # Render Source Citations for assistant
            sources = msg.get("sources", [])
            if sources:
                st.markdown("##### 📚 Verified Sources:")
                for cit in sources:
                    src_name = cit.get("source", "College Source")
                    page_num = cit.get("page", 1)
                    snippet = cit.get("snippet", "")
                    st.markdown(
                        f"""
                        <div class="citation-card">
                            <div class="citation-title">📄 {src_name} (Page {page_num})</div>
                            <div class="citation-snippet">"{snippet}"</div>
                        </div>
                        """,
                        unsafe_allow_html=True
                    )

    # Process Input
    user_query = st.chat_input("Ask about timetable, exams, faculty, attendance, fees, scholarships...")
    if selected_prompt:
        user_query = selected_prompt

    if user_query:
        # Add user message
        st.session_state.chat_messages.append({"role": "user", "content": user_query})
        with st.chat_message("user", avatar="🧑‍🎓"):
            st.markdown(user_query)

        # Agent Execution
        with st.chat_message("assistant", avatar="🎓"):
            with st.spinner("Agent analyzing question and selecting tool..."):
                result = st.session_state.agent_service.handle_query(
                    query=user_query,
                    session_id=st.session_state.session_id,
                    conversation_history=st.session_state.chat_messages[:-1]
                )

                tool_used = result.get("tool_used", "Agent")
                latency_str = format_latency(result.get("latency_seconds", 0.0))
                sources = result.get("sources", [])

                # Render Tool Badge
                st.markdown(
                    f"<span class='tool-badge'>🎯 Routed to: {tool_used} ({latency_str})</span>",
                    unsafe_allow_html=True
                )

                # Render Answer
                st.markdown(result["answer"])

                # Render Sources
                if sources:
                    st.markdown("##### 📚 Verified Sources:")
                    for cit in sources:
                        src_name = cit.get("source", "College Source")
                        page_num = cit.get("page", 1)
                        snippet = cit.get("snippet", "")
                        st.markdown(
                            f"""
                            <div class="citation-card">
                                <div class="citation-title">📄 {src_name} (Page {page_num})</div>
                                <div class="citation-snippet">"{snippet}"</div>
                            </div>
                            """,
                            unsafe_allow_html=True
                        )

                # Save assistant turn
                st.session_state.chat_messages.append({
                    "role": "assistant",
                    "content": result["answer"],
                    "tool_used": tool_used,
                    "latency": latency_str,
                    "sources": sources
                })

                st.rerun()


# ==============================================================================
# PAGE 2: ADMIN PANEL
# ==============================================================================

elif selected_page == "🛠️ Admin Panel":
    st.markdown(
        """
        <div class="main-header" style="background: linear-gradient(135deg, #0f172a 0%, #334155 100%);">
            <div class="main-title">
                <span>🛠️</span> College Assistant — Administrator Panel
            </div>
            <div class="main-subtitle">
                Document Ingestion Pipeline • ChromaDB Vector Store • SQLite Knowledge Base Management
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )

    admin_svc: AdminService = st.session_state.admin_service

    tab_upload, tab_kb, tab_sql = st.tabs([
        "📥 Document Ingestion",
        "📚 ChromaDB Knowledge Base",
        "🗄️ SQLite Database Overview"
    ])

    # Tab 1: Document Upload & Ingestion
    with tab_upload:
        st.subheader("Upload & Index College PDF Documents")
        st.caption("Upload college handbooks, syllabus, regulations, or circulars to automatically process and index into ChromaDB.")

        uploaded_file = st.file_uploader(
            "Choose a PDF or TXT file",
            type=["pdf", "txt"],
            key="admin_pdf_uploader"
        )

        if uploaded_file is not None:
            col_info1, col_info2 = st.columns(2)
            with col_info1:
                st.write(f"📄 **Filename:** `{uploaded_file.name}`")
            with col_info2:
                st.write(f"📦 **Size:** `{format_file_size(uploaded_file.size)}`")

            if st.button("🚀 Ingest & Index Document", type="primary", use_container_width=True):
                with st.spinner(f"Ingesting '{uploaded_file.name}' into ChromaDB..."):
                    res = admin_svc.save_and_ingest(
                        filename=uploaded_file.name,
                        file_bytes=uploaded_file.getvalue()
                    )

                    if res.get("success"):
                        st.success(
                            f"✅ Successfully indexed **{uploaded_file.name}**! "
                            f"({res.get('chunks_indexed', 0)} chunks created in {res.get('time_taken_seconds', 0)}s)"
                        )
                        st.rerun()
                    else:
                        st.error(f"❌ Ingestion failed: {res.get('error')}")

        st.markdown("---")
        st.markdown("#### ⚡ Batch Ingest Sample Handbooks")
        st.caption("Automatically index all pre-packaged university documents located in `data/documents/`.")

        if st.button("📥 Index All Sample Documents", use_container_width=True):
            with st.spinner("Indexing all sample documents in data/documents/..."):
                summary = admin_svc.ingest_sample_documents()
                st.success(
                    f"✅ Ingested {summary['files_indexed']}/{summary['total_files_found']} files "
                    f"({summary['total_chunks_added']} chunks added to ChromaDB)."
                )
                if summary.get("errors"):
                    st.warning(f"Encountered issues: {summary['errors']}")
                st.rerun()

    # Tab 2: ChromaDB Knowledge Base Inspection
    with tab_kb:
        st.subheader("ChromaDB Vector Store Inventory")
        kb_info = admin_svc.vector_store.get_stats()

        col_k1, col_k2, col_k3 = st.columns(3)
        with col_k1:
            st.metric("Total Chunks", kb_info.get("total_chunks", 0))
        with col_k2:
            st.metric("Distinct Documents", kb_info.get("total_documents", 0))
        with col_k3:
            st.metric("Vector Dimension", f"{kb_info.get('vector_dimension', 384)} dims")

        st.markdown("##### 📑 Documents Currently in Vector Store:")
        sources = kb_info.get("document_sources", [])
        if not sources:
            st.info("The vector database is currently empty. Upload documents or click 'Index All Sample Documents'.")
        else:
            for s in sources:
                col_d1, col_d2 = st.columns([5, 1])
                with col_d1:
                    st.write(f"📄 **{s}**")
                with col_d2:
                    if st.button("🗑️ Delete", key=f"del_kb_{s}"):
                        admin_svc.delete_document(s)
                        st.success(f"Removed '{s}' from ChromaDB.")
                        st.rerun()

        st.markdown("---")
        if st.button("⚠️ Clear Entire Vector Store", use_container_width=True):
            admin_svc.reset_knowledge_base()
            st.warning("All embeddings cleared from ChromaDB.")
            st.rerun()

    # Tab 3: SQLite Database Overview
    with tab_sql:
        st.subheader("Structured SQLite Database Records")
        st.caption(f"Database Location: `{Config.DATABASE_PATH}`")

        counts = get_table_counts()
        cols_c = st.columns(4)
        c_items = list(counts.items())

        for idx, (tbl, count) in enumerate(c_items):
            with cols_c[idx % 4]:
                st.metric(tbl.replace("_", " ").title(), count)

        st.markdown("---")
        if st.button("🔄 Re-Seed SQLite Database with Default College Data", use_container_width=True):
            admin_svc.reset_database()
            st.success("SQLite database re-seeded successfully.")
            st.rerun()
