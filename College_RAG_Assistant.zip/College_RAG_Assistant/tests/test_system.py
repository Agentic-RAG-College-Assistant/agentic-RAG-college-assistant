"""
End-to-End System Test Suite.
Verifies the complete workflow of the Agentic RAG College Assistant.
"""

import unittest
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# Ensure utf-8 output on Windows console
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from src.agent.agent_service import CollegeAgentService
from src.database.crud import seed_database_if_empty, get_chat_history


class TestSystem(unittest.TestCase):
    """Integration test suite for the complete College Assistant system."""

    @classmethod
    def setUpClass(cls):
        seed_database_if_empty()
        cls.agent = CollegeAgentService()
        cls.session_id = "test_system_session"

    def test_query_class_timetable_routing(self):
        """Tests end-to-end routing to SQLite class timetables."""
        q = "What is Monday's class schedule for CSE 3rd sem?"
        res = self.agent.handle_query(q, session_id=self.session_id)

        self.assertEqual(res["intent"], "CLASS_TIMETABLE")
        self.assertIn("SQLite Class Timetable Tool", res["tool_used"])
        self.assertIn("Class Schedule", res["answer"])
        self.assertGreater(len(res["sources"]), 0)

    def test_query_exam_timetable_routing(self):
        """Tests end-to-end routing to SQLite exam timetables."""
        q = "When is the examination timetable for CSE 3rd sem?"
        res = self.agent.handle_query(q, session_id=self.session_id)

        self.assertEqual(res["intent"], "EXAM_TIMETABLE")
        self.assertIn("SQLite Exam Timetable Tool", res["tool_used"])
        self.assertIn("Examination Timetable", res["answer"])

    def test_query_faculty_info_routing(self):
        """Tests end-to-end routing to SQLite faculty directory."""
        q = "Who is the HOD of Computer Science and what is their email?"
        res = self.agent.handle_query(q, session_id=self.session_id)

        self.assertEqual(res["intent"], "FACULTY_INFO")
        self.assertIn("Dr. Ananya Sen", res["answer"])
        self.assertIn("ananya.sen@apexuniv.edu.in", res["answer"])

    def test_query_document_rag_attendance(self):
        """Tests end-to-end routing to ChromaDB Document RAG for attendance policy."""
        q = "What is the minimum attendance requirement and detention policy?"
        res = self.agent.handle_query(q, session_id=self.session_id)

        self.assertEqual(res["intent"], "DOCUMENT_RAG")
        self.assertIn("ChromaDB Document RAG Pipeline", res["tool_used"])
        self.assertIn("75%", res["answer"])
        self.assertGreater(len(res["sources"]), 0)
        self.assertEqual(res["sources"][0]["source"], "Academic_Regulations_and_Attendance.txt")

    def test_query_document_rag_fees(self):
        """Tests end-to-end routing to ChromaDB Document RAG for fees."""
        q = "What is the tuition fee for B.Tech CSE and MBA per semester?"
        res = self.agent.handle_query(q, session_id=self.session_id)

        self.assertEqual(res["intent"], "DOCUMENT_RAG")
        self.assertTrue("1,45,000" in res["answer"] or "Tuition_Fees" in str(res["sources"]))

    def test_chat_history_logging(self):
        """Verifies conversation turns are logged to SQLite chat_history table."""
        test_session = "test_independent_logging_session"
        # Execute a message first to populate the session
        self.agent.handle_query("Hello assistant", session_id=test_session)

        history = get_chat_history(session_id=test_session, limit=10)
        self.assertGreater(len(history), 0, "Chat turns must be persisted in SQLite.")
        roles = [h["role"] for h in history]
        self.assertIn("user", roles)
        self.assertIn("assistant", roles)


if __name__ == "__main__":
    unittest.main()
