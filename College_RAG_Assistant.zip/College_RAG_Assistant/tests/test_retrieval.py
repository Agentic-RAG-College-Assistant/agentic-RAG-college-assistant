"""
Unit tests for ChromaDB Vector Store & Semantic Retrieval.
"""

import unittest
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.retrieval.vector_store import ChromaVectorStore
from src.retrieval.retriever import CollegeRetriever


class TestRetrieval(unittest.TestCase):
    """Tests ChromaDB storage and similarity search."""

    @classmethod
    def setUpClass(cls):
        cls.vector_store = ChromaVectorStore()
        cls.retriever = CollegeRetriever(vector_store=cls.vector_store)

    def test_chroma_collection_ready(self):
        """Verifies ChromaDB collection exists and holds documents."""
        stats = self.vector_store.get_stats()
        self.assertGreater(stats["total_chunks"], 0, "Collection should contain indexed chunks.")
        self.assertEqual(stats["vector_dimension"], 384)

    def test_similarity_search_attendance(self):
        """Tests retrieval for attendance questions."""
        results = self.retriever.retrieve("What is the minimum attendance requirement?")
        self.assertGreater(len(results), 0, "Should retrieve chunks for attendance query.")

        # Top chunk should mention 75% or attendance
        top_text = results[0]["text"]
        self.assertTrue("attendance" in top_text.lower() or "75%" in top_text)

    def test_similarity_search_scholarships(self):
        """Tests retrieval for scholarship policies."""
        results = self.retriever.retrieve("What scholarships are given for high CGPA?")
        self.assertGreater(len(results), 0, "Should retrieve chunks for scholarship query.")
        top_text = results[0]["text"]
        self.assertTrue("scholarship" in top_text.lower() or "cgpa" in top_text.lower() or "fellowship" in top_text.lower())


if __name__ == "__main__":
    unittest.main()
