"""
Unit tests for Document Ingestion: Loader, Chunker, and Embeddings.
"""

import unittest
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.config import Config
from src.ingestion.document_loader import DocumentLoader, Document
from src.ingestion.text_chunker import TextChunker
from src.ingestion.embedding_service import EmbeddingService


class TestIngestion(unittest.TestCase):
    """Tests document loading, chunking, and embeddings generation."""

    def test_document_loader_txt(self):
        """Tests loading text documents."""
        sample_file = Config.DOCUMENTS_DIR / "Academic_Regulations_and_Attendance.txt"
        self.assertTrue(sample_file.exists(), "Sample document does not exist.")

        docs = DocumentLoader.load_document(sample_file)
        self.assertGreater(len(docs), 0, "Loader should extract at least one document unit.")
        self.assertEqual(docs[0].metadata["source"], sample_file.name)
        self.assertIn("75%", docs[0].text)

    def test_text_chunker(self):
        """Tests recursive semantic text chunking."""
        sample_text = (
            "This is paragraph one of academic policy. It covers the attendance rules.\n\n"
            "This is paragraph two. Students must maintain 75% attendance across all subjects.\n\n"
            "This is paragraph three discussing condonation and detention below 65%."
        )
        doc = Document(text=sample_text, metadata={"source": "test_doc.txt", "page": 1})
        chunker = TextChunker(chunk_size=120, chunk_overlap=30)
        chunks = chunker.split_document(doc)

        self.assertGreater(len(chunks), 1, "Should split text into multiple chunks.")
        for c in chunks:
            self.assertEqual(c.metadata["source"], "test_doc.txt")
            self.assertIn("chunk_id", c.metadata)

    def test_embedding_service(self):
        """Tests SentenceTransformer embeddings shape and dimension."""
        service = EmbeddingService()
        self.assertEqual(service.dimension, 384, "all-MiniLM-L6-v2 dimension must be 384.")

        vec = service.embed_query("What is the attendance requirement?")
        self.assertEqual(len(vec), 384)

        batch_vecs = service.embed_texts(["Class timetable", "Hostel accommodation"])
        self.assertEqual(len(batch_vecs), 2)
        self.assertEqual(len(batch_vecs[0]), 384)


if __name__ == "__main__":
    unittest.main()
