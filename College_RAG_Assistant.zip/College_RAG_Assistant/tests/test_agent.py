"""
Unit tests for Agent Router and Specialized Tools.
"""

import unittest
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.agent.agent_router import (
    AgentRouter,
    INTENT_EXAM_TIMETABLE,
    INTENT_CLASS_TIMETABLE,
    INTENT_FACULTY_INFO,
    INTENT_NOTICES,
    INTENT_STUDENT_INFO,
    INTENT_DOCUMENT_RAG,
    INTENT_GREETING
)
from src.agent import tools
from src.database.crud import seed_database_if_empty


class TestAgent(unittest.TestCase):
    """Tests AgentRouter intent classification and individual tools."""

    @classmethod
    def setUpClass(cls):
        seed_database_if_empty()
        cls.router = AgentRouter()

    def test_routing_greeting(self):
        intent, _ = self.router.route_query("Hello there!")
        self.assertEqual(intent, INTENT_GREETING)

    def test_routing_class_timetable(self):
        intent, entities = self.router.route_query("What is the class timetable for CSE 3rd sem on Monday?")
        self.assertEqual(intent, INTENT_CLASS_TIMETABLE)
        self.assertEqual(entities["department"], "CSE")
        self.assertEqual(entities["semester"], 3)
        self.assertEqual(entities["day"], "Monday")

    def test_routing_exam_timetable(self):
        intent, entities = self.router.route_query("When is the examination schedule for CSE sem 3?")
        self.assertEqual(intent, INTENT_EXAM_TIMETABLE)
        self.assertEqual(entities["department"], "CSE")
        self.assertEqual(entities["semester"], 3)

    def test_routing_faculty_info(self):
        intent, _ = self.router.route_query("Who is the HOD of Computer Science department?")
        self.assertEqual(intent, INTENT_FACULTY_INFO)

    def test_routing_notices(self):
        intent, _ = self.router.route_query("Show me the latest college notices and announcements")
        self.assertEqual(intent, INTENT_NOTICES)

    def test_routing_student_info(self):
        intent, entities = self.router.route_query("Check attendance for roll number 22CS001")
        self.assertEqual(intent, INTENT_STUDENT_INFO)
        self.assertEqual(entities["roll_no"], "22CS001")

    def test_routing_document_rag(self):
        intent, _ = self.router.route_query("What is the 75% attendance requirement and detention policy?")
        self.assertEqual(intent, INTENT_DOCUMENT_RAG)

    def test_tools_execution(self):
        """Tests that tools produce structured outputs without errors."""
        t1 = tools.class_timetable_tool("CSE", 3, "Monday")
        self.assertIn("Class Schedule", t1["text"])
        self.assertGreater(t1["records_found"], 0)

        t2 = tools.exam_timetable_tool("CSE", 3)
        self.assertIn("Examination Timetable", t2["text"])
        self.assertGreater(t2["records_found"], 0)

        t3 = tools.faculty_info_tool("HOD", "CSE")
        self.assertIn("Dr. Ananya Sen", t3["text"])

        t4 = tools.student_info_tool("22CS001")
        self.assertIn("Aarav Sharma", t4["text"])


if __name__ == "__main__":
    unittest.main()
