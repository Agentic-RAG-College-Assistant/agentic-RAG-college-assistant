# 🎓 Agentic RAG-Based College Assistant

An enterprise-grade, beginner-friendly **Agentic Retrieval-Augmented Generation (RAG)** assistant engineered for university students, faculty, and academic administrators. 

Unlike traditional chatbots that simply search PDF text, this assistant implements an **Agentic Cognitive Architecture** that dynamically classifies student intent, extracts query parameters, and routes the query to the optimal information source:
1. **SQLite Database Engine**: For structured relational data (Timetables, Exam Dates, Faculty Directories, Department Heads, Notices, and Student Grades).
2. **ChromaDB Vector Store**: For unstructured PDF documents (Syllabus, Academic Regulations, Attendance & Detention Guidelines, Fee Policies, and Placement Handbooks).

---

## 🏛️ System Architecture

```
                               ┌───────────────────────────────────┐
                               │       Student / User Query        │
                               └─────────────────┬─────────────────┘
                                                 │
                                                 ▼
                               ┌───────────────────────────────────┐
                               │           AGENT ROUTER            │
                               │   • Intent & Entity Extraction    │
                               │   • Category Classification       │
                               └─────────────────┬─────────────────┘
                                                 │
                   ┌─────────────────────────────┴─────────────────────────────┐
                   ▼                                                           ▼
    ┌───────────────────────────────┐                           ┌───────────────────────────────┐
    │     STRUCTURED SQL ROUTE      │                           │      DOCUMENT RAG ROUTE       │
    │  (Exams, Schedule, Faculty)   │                           │    (PDFs, Rules, Policies)    │
    └──────────────┬────────────────┘                           └──────────────┬────────────────┘
                   │                                                           │
                   ▼                                                           ▼
    ┌───────────────────────────────┐                           ┌───────────────────────────────┐
    │     SQLite DATABASE (CRUD)    │                           │      ChromaDB VECTOR STORE    │
    │  • departments, faculty       │                           │  • all-MiniLM-L6-v2 Embeddings│
    │  • class_timetables           │                           │  • Cosine Similarity Search   │
    │  • exam_timetables            │                           │  • Top-K Semantic Filtering   │
    │  • notices, students          │                           └──────────────┬────────────────┘
    └──────────────┬────────────────┘                                          │
                   │                                                           ▼
                   │                                            ┌───────────────────────────────┐
                   │                                            │          LLM SERVICE          │
                   │                                            │  • OpenAI / Groq / Ollama     │
                   │                                            │  • Built-in Offline Fallback  │
                   │                                            │  • Grounding & Anti-Halluc.   │
                   │                                            └──────────────┬────────────────┘
                   │                                                           │
                   └─────────────────────────────┬─────────────────────────────┘
                                                 │
                                                 ▼
                               ┌───────────────────────────────────┐
                               │      RESPONSE & CITATIONS         │
                               │  • Standardized Academic Answer   │
                               │  • Traceable Source Citations     │
                               │  • Session Memory in SQLite       │
                               └───────────────────────────────────┘
```

---

## 🚀 Key Features

1. **Intelligent Agent Router**: Automatically routes questions to the appropriate tool (e.g. *"When is the DBMS exam?"* -> SQLite Exam Tool; *"What is the 75% attendance rule?"* -> ChromaDB Document RAG).
2. **Persistent ChromaDB Vector Store**: Indexes college PDFs into 384-dimensional dense vectors using Hugging Face's `all-MiniLM-L6-v2`.
3. **Structured SQLite Database**: Stores relational tables for Faculty, Class Timetables, Exam Schedules, Notices, and Student records with foreign key relationships.
4. **Offline-First & Local Friendly**: Runs completely on your local Windows PC without needing external paid API keys. An OpenAI/Groq API key can optionally be plugged into `.env`.
5. **Streamlit UI**:
   - **Student Chatbot**: Conversational chat with memory, routing badges, and expandable source citations.
   - **Admin Panel**: Drag-and-drop PDF upload, instant ingestion, knowledge base inventory, document deletion, and database re-seeding.
6. **Strict Hallucination Control**: Responses are strictly grounded in retrieved documents and databases. If information is missing, the system clearly informs the student.

---

## 📂 Project Directory Structure

```text
College_RAG_Assistant/
│
├── app.py                         # Streamlit Application (Student Chatbot + Admin Panel)
├── requirements.txt               # Dependencies
├── README.md                      # Documentation
├── .env.example                   # Environment configuration template
├── .env                           # Local environment file
├── .gitignore                     # Git ignore rules
│
├── data/
│   ├── documents/                 # Official pre-packaged college handbooks
│   ├── uploads/                   # Admin uploaded PDF files
│   └── processed/                 # Intermediate processing
│
├── database/
│   └── college.db                 # SQLite relational database
│
├── vectorstore/
│   └── chroma_db/                 # Persistent ChromaDB vector index
│
├── src/
│   ├── config.py                  # Paths, constants, and settings
│   │
│   ├── database/                  # SQLite Database Layer
│   │   ├── db.py                  # Connection & schema initialization
│   │   ├── models.py              # SQL table definitions
│   │   └── crud.py                # CRUD queries & sample data seeding
│   │
│   ├── ingestion/                 # Document Processing Pipeline
│   │   ├── document_loader.py     # PDF & TXT page text extraction (PyPDF)
│   │   ├── text_chunker.py        # Recursive semantic chunking (700 chars, 120 overlap)
│   │   ├── embedding_service.py   # SentenceTransformer embeddings
│   │   └── ingestion_pipeline.py  # Coordinates Load -> Chunk -> Embed -> Store
│   │
│   ├── retrieval/                 # Vector Retrieval Subsystem
│   │   ├── vector_store.py        # ChromaDB persistent client wrapper
│   │   ├── retriever.py           # Acronym expansion & cosine search
│   │   └── rag_pipeline.py        # RAG Pipeline with citation builder
│   │
│   ├── agent/                     # Agentic Router & Tools Layer
│   │   ├── agent_router.py        # Intent classifier & entity extractor
│   │   ├── tools.py               # Individual SQLite & RAG tools
│   │   └── agent_service.py       # Master agent coordinator & memory logger
│   │
│   ├── llm/                       # LLM Service Layer
│   │   └── llm_service.py         # OpenAI/Groq API client + offline synthesizer
│   │
│   ├── admin/                     # Admin Services
│   │   └── admin_service.py       # Knowledge base status, uploads, purging
│   │
│   └── utils/                     # Utilities
│       ├── logger.py              # Console & rotating file logger (logs/app.log)
│       └── helpers.py             # Input sanitization, citation formatting
│
└── tests/                         # Automated Unit & Integration Tests
    ├── test_ingestion.py          # Validates loader, chunker, embeddings
    ├── test_retrieval.py          # Validates ChromaDB storage & search
    ├── test_agent.py              # Validates intent routing & tools
    └── test_system.py             # Complete end-to-end integration test
```

---

## 🛠️ Installation & Setup Guide

### Step 1: Open PowerShell in Project Folder
```powershell
cd "C:\Users\DeLL\Documents\College_RAG_Assistant"
```

### Step 2: Create and Activate Virtual Environment
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

### Step 3: Install Required Dependencies
```powershell
pip install -r requirements.txt
```

### Step 4: Configure Environment Variables
Copy `.env.example` to `.env`:
```powershell
cp .env.example .env
```
*(Optional)* If you have an OpenAI or Groq API key, add it to `.env`:
```ini
OPENAI_API_KEY=your_key_here
LLM_MODEL=gpt-3.5-turbo
```
> **Note for Beginners:** If you do not have an API key, leave `OPENAI_API_KEY=` blank! The system automatically uses its built-in local academic response synthesizer so you can run it 100% offline for free!

---

## 🚀 Running the Streamlit Application

Execute the following PowerShell command:
```powershell
streamlit run app.py
```

Open your browser and navigate to:
```text
http://localhost:8501
```

---

## 🧪 Running Automated Tests

Run the complete test suite:
```powershell
cd "C:\Users\DeLL\Documents\College_RAG_Assistant"
python -m unittest discover -s tests -p "test_*.py" -v
```

Expected Output:
```text
test_document_loader_txt (test_ingestion.TestIngestion) ... ok
test_embedding_service (test_ingestion.TestIngestion) ... ok
test_text_chunker (test_ingestion.TestIngestion) ... ok
test_chroma_collection_ready (test_retrieval.TestRetrieval) ... ok
test_similarity_search_attendance (test_retrieval.TestRetrieval) ... ok
test_similarity_search_scholarships (test_retrieval.TestRetrieval) ... ok
test_routing_class_timetable (test_agent.TestAgent) ... ok
test_routing_document_rag (test_agent.TestAgent) ... ok
test_routing_exam_timetable (test_agent.TestAgent) ... ok
test_routing_faculty_info (test_agent.TestAgent) ... ok
test_query_class_timetable_routing (test_system.TestSystem) ... ok
test_query_document_rag_attendance (test_system.TestSystem) ... ok
...
Ran 17 tests in 3.42s
OK
```

---

## 💡 Sample Questions to Test

| Question Type | Sample Student Question | Expected Agent Tool | Information Source |
|---|---|---|---|
| **Class Timetable** | *"What is Monday's class schedule for CSE 3rd sem?"* | `SQLite Class Timetable Tool` | SQLite `class_timetables` table |
| **Exam Timetable** | *"When is the examination for Database Management Systems?"* | `SQLite Exam Timetable Tool` | SQLite `exam_timetables` table |
| **Faculty Info** | *"Who is the HOD of Computer Science and their email?"* | `SQLite Faculty Directory Tool` | SQLite `faculty` & `departments` |
| **Notices** | *"Show me the latest college notices and announcements"* | `SQLite Notices Tool` | SQLite `notices` table |
| **Student Info** | *"Check attendance record for roll number 22CS001"* | `SQLite Student Information Tool` | SQLite `students` table |
| **Document RAG** | *"What is the minimum attendance requirement and detention policy?"* | `ChromaDB Document RAG Pipeline` | `Academic_Regulations_and_Attendance.txt` |
| **Document RAG** | *"What are the tuition fees and scholarships?"* | `ChromaDB Document RAG Pipeline` | `Tuition_Fees_and_Scholarships_Policy.txt` |
| **Document RAG** | *"What was the highest package for campus placements?"* | `ChromaDB Document RAG Pipeline` | `Campus_Placements_and_Internships_Handbook.txt` |
| **Greeting** | *"Hello, what can you help me with?"* | `System Greeting Tool` | Built-in conversational guidance |
