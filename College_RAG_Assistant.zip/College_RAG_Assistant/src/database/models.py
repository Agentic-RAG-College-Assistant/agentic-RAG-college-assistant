"""
Database Models and Table Schemas for College SQLite Database.
Defines SQL CREATE TABLE statements and dataclass representations.
"""

# SQL statements to create tables for structured college information

CREATE_DEPARTMENTS_TABLE = """
CREATE TABLE IF NOT EXISTS departments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    hod_name TEXT NOT NULL,
    contact_email TEXT NOT NULL
);
"""

CREATE_FACULTY_TABLE = """
CREATE TABLE IF NOT EXISTS faculty (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    department_id INTEGER NOT NULL,
    designation TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    office_room TEXT NOT NULL,
    FOREIGN KEY (department_id) REFERENCES departments (id)
);
"""

CREATE_SUBJECTS_TABLE = """
CREATE TABLE IF NOT EXISTS subjects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    department_id INTEGER NOT NULL,
    semester INTEGER NOT NULL,
    credits INTEGER NOT NULL,
    FOREIGN KEY (department_id) REFERENCES departments (id)
);
"""

CREATE_CLASS_TIMETABLES_TABLE = """
CREATE TABLE IF NOT EXISTS class_timetables (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    department_id INTEGER NOT NULL,
    semester INTEGER NOT NULL,
    day_of_week TEXT NOT NULL,
    time_slot TEXT NOT NULL,
    subject_code TEXT NOT NULL,
    subject_name TEXT NOT NULL,
    room_no TEXT NOT NULL,
    FOREIGN KEY (department_id) REFERENCES departments (id)
);
"""

CREATE_EXAM_TIMETABLES_TABLE = """
CREATE TABLE IF NOT EXISTS exam_timetables (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    department_id INTEGER NOT NULL,
    semester INTEGER NOT NULL,
    subject_code TEXT NOT NULL,
    subject_name TEXT NOT NULL,
    exam_date TEXT NOT NULL,
    time_slot TEXT NOT NULL,
    room_no TEXT NOT NULL,
    FOREIGN KEY (department_id) REFERENCES departments (id)
);
"""

CREATE_NOTICES_TABLE = """
CREATE TABLE IF NOT EXISTS notices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    date_posted TEXT NOT NULL,
    content TEXT NOT NULL,
    active INTEGER DEFAULT 1
);
"""

CREATE_STUDENTS_TABLE = """
CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    roll_no TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    department_id INTEGER NOT NULL,
    semester INTEGER NOT NULL,
    cgpa REAL NOT NULL,
    attendance_pct REAL NOT NULL,
    FOREIGN KEY (department_id) REFERENCES departments (id)
);
"""

CREATE_CHAT_HISTORY_TABLE = """
CREATE TABLE IF NOT EXISTS chat_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    tool_used TEXT DEFAULT 'None',
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);
"""

CREATE_DOCUMENTS_META_TABLE = """
CREATE TABLE IF NOT EXISTS uploaded_documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    filename TEXT UNIQUE NOT NULL,
    file_path TEXT NOT NULL,
    file_size_bytes INTEGER NOT NULL,
    upload_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    chunk_count INTEGER DEFAULT 0,
    status TEXT DEFAULT 'Indexed'
);
"""

ALL_TABLES = [
    CREATE_DEPARTMENTS_TABLE,
    CREATE_FACULTY_TABLE,
    CREATE_SUBJECTS_TABLE,
    CREATE_CLASS_TIMETABLES_TABLE,
    CREATE_EXAM_TIMETABLES_TABLE,
    CREATE_NOTICES_TABLE,
    CREATE_STUDENTS_TABLE,
    CREATE_CHAT_HISTORY_TABLE,
    CREATE_DOCUMENTS_META_TABLE,
]
