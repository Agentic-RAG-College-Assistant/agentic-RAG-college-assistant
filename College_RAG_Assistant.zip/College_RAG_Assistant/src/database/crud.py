"""
CRUD (Create, Read, Update, Delete) Operations & Initial Data Seeding for SQLite Database.
Provides query functions for faculty, timetables, notices, students, and chat history.
"""

from typing import List, Dict, Any, Optional
from src.database.db import get_db_connection, init_db
from src.utils.logger import get_logger

logger = get_logger("DatabaseCRUD")


# ==============================================================================
# FACULTY & DEPARTMENTS QUERIES
# ==============================================================================

def get_all_departments() -> List[Dict[str, Any]]:
    """Retrieves all academic departments."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM departments ORDER BY code")
    rows = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return rows


def get_faculty(keyword: Optional[str] = None, dept_code: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Finds faculty members by name, designation, or department code.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    query = """
    SELECT f.id, f.name, f.designation, f.email, f.office_room, d.code as dept_code, d.name as dept_name
    FROM faculty f
    JOIN departments d ON f.department_id = d.id
    WHERE 1=1
    """
    params = []

    if dept_code:
        query += " AND (LOWER(d.code) = LOWER(?) OR LOWER(d.name) LIKE ?)"
        params.extend([dept_code, f"%{dept_code.lower()}%"])

    if keyword:
        query += " AND (LOWER(f.name) LIKE ? OR LOWER(f.designation) LIKE ? OR LOWER(d.name) LIKE ?)"
        term = f"%{keyword.lower()}%"
        params.extend([term, term, term])

    query += " ORDER BY f.name"

    cursor.execute(query, params)
    rows = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return rows


# ==============================================================================
# TIMETABLES (CLASS & EXAM)
# ==============================================================================

def get_class_timetable(
    dept_code: Optional[str] = None,
    semester: Optional[int] = None,
    day_of_week: Optional[str] = None
) -> List[Dict[str, Any]]:
    """
    Retrieves weekly lecture schedules filtered by department, semester, and day.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    query = """
    SELECT t.day_of_week, t.time_slot, t.subject_code, t.subject_name, t.room_no,
           t.semester, d.code as dept_code, d.name as dept_name
    FROM class_timetables t
    JOIN departments d ON t.department_id = d.id
    WHERE 1=1
    """
    params = []

    if dept_code:
        query += " AND (LOWER(d.code) = LOWER(?) OR LOWER(d.name) LIKE ?)"
        params.extend([dept_code, f"%{dept_code.lower()}%"])

    if semester:
        query += " AND t.semester = ?"
        params.append(semester)

    if day_of_week:
        query += " AND LOWER(t.day_of_week) = LOWER(?)"
        params.append(day_of_week)

    query += " ORDER BY t.day_of_week, t.time_slot"

    cursor.execute(query, params)
    rows = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return rows


def get_exam_timetable(
    dept_code: Optional[str] = None,
    semester: Optional[int] = None
) -> List[Dict[str, Any]]:
    """
    Retrieves upcoming semester examination schedules.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    query = """
    SELECT e.exam_date, e.time_slot, e.subject_code, e.subject_name, e.room_no,
           e.semester, d.code as dept_code, d.name as dept_name
    FROM exam_timetables e
    JOIN departments d ON e.department_id = d.id
    WHERE 1=1
    """
    params = []

    if dept_code:
        query += " AND (LOWER(d.code) = LOWER(?) OR LOWER(d.name) LIKE ?)"
        params.extend([dept_code, f"%{dept_code.lower()}%"])

    if semester:
        query += " AND e.semester = ?"
        params.append(semester)

    query += " ORDER BY e.exam_date, e.time_slot"

    cursor.execute(query, params)
    rows = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return rows


# ==============================================================================
# NOTICES & ANNOUNCEMENTS
# ==============================================================================

def get_notices(category: Optional[str] = None, limit: int = 5) -> List[Dict[str, Any]]:
    """
    Fetches active college notices, sorted by most recent date.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    query = "SELECT * FROM notices WHERE active = 1"
    params = []

    if category:
        query += " AND LOWER(category) = LOWER(?)"
        params.append(category)

    query += " ORDER BY date_posted DESC LIMIT ?"
    params.append(limit)

    cursor.execute(query, params)
    rows = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return rows


# ==============================================================================
# STUDENT INFORMATION
# ==============================================================================

def get_student_info(roll_no: str) -> Optional[Dict[str, Any]]:
    """
    Retrieves student details (attendance, CGPA, semester, department) by roll number.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    query = """
    SELECT s.roll_no, s.name, s.semester, s.cgpa, s.attendance_pct,
           d.code as dept_code, d.name as dept_name
    FROM students s
    JOIN departments d ON s.department_id = d.id
    WHERE LOWER(s.roll_no) = LOWER(?)
    """
    cursor.execute(query, (roll_no.strip(),))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


# ==============================================================================
# CHAT HISTORY CONVERSATIONAL MEMORY
# ==============================================================================

def add_chat_message(session_id: str, role: str, content: str, tool_used: str = "None") -> int:
    """Saves a conversation turn to SQLite chat_history."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO chat_history (session_id, role, content, tool_used) VALUES (?, ?, ?, ?)",
        (session_id, role, content, tool_used)
    )
    conn.commit()
    msg_id = cursor.lastrowid
    conn.close()
    return msg_id


def get_chat_history(session_id: str, limit: int = 10) -> List[Dict[str, Any]]:
    """Fetches recent chat history for a session."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT role, content, tool_used, timestamp FROM chat_history WHERE session_id = ? ORDER BY id ASC LIMIT ?",
        (session_id, limit)
    )
    rows = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return rows


# ==============================================================================
# DOCUMENT REGISTRY (SQLITE TRACKING)
# ==============================================================================

def register_document(filename: str, file_path: str, file_size_bytes: int, chunk_count: int = 0) -> bool:
    """Registers an uploaded document in the database."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            """
            INSERT OR REPLACE INTO uploaded_documents (filename, file_path, file_size_bytes, chunk_count, status)
            VALUES (?, ?, ?, ?, 'Indexed')
            """,
            (filename, file_path, file_size_bytes, chunk_count)
        )
        conn.commit()
        return True
    except Exception as e:
        logger.error(f"Error registering document in DB: {e}")
        return False
    finally:
        conn.close()


def get_all_registered_documents() -> List[Dict[str, Any]]:
    """Returns all documents logged in SQLite."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM uploaded_documents ORDER BY upload_timestamp DESC")
    rows = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return rows


def delete_document_record(filename: str) -> bool:
    """Removes a document from the tracking table."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM uploaded_documents WHERE filename = ?", (filename,))
    conn.commit()
    conn.close()
    return True


# ==============================================================================
# DATABASE SEEDING (POPULATES REALISTIC UNIVERSITY DATA)
# ==============================================================================

def seed_database_if_empty():
    """
    Seeds the database with departments, faculty, timetables, subjects, and notices.
    Runs once when tables are empty.
    """
    init_db()
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM departments")
    if cursor.fetchone()[0] > 0:
        conn.close()
        return  # Already seeded

    logger.info("Seeding SQLite database with college records...")

    # 1. Departments
    departments = [
        ("CSE", "Computer Science & Engineering", "Dr. Ananya Sen", "hod.cse@apexuniv.edu.in"),
        ("ECE", "Electronics & Communication Engineering", "Prof. Vikram Malhotra", "hod.ece@apexuniv.edu.in"),
        ("MECH", "Mechanical Engineering", "Dr. Harish Balakrishnan", "hod.mech@apexuniv.edu.in"),
        ("MBA", "School of Management", "Prof. Deepak Varma", "hod.mba@apexuniv.edu.in"),
    ]
    cursor.executemany(
        "INSERT INTO departments (code, name, hod_name, contact_email) VALUES (?, ?, ?, ?)",
        departments
    )

    # 2. Faculty
    faculty_data = [
        ("Dr. Ananya Sen", 1, "Professor & HOD", "ananya.sen@apexuniv.edu.in", "CS-301"),
        ("Prof. Rahul Deshmukh", 1, "Associate Professor", "rahul.d@apexuniv.edu.in", "CS-204"),
        ("Dr. Priya Venkatesh", 1, "Assistant Professor", "priya.v@apexuniv.edu.in", "CS-108"),
        ("Prof. Vikram Malhotra", 2, "Professor & HOD", "vikram.m@apexuniv.edu.in", "EC-205"),
        ("Dr. Neha Tiwari", 2, "Associate Professor", "neha.t@apexuniv.edu.in", "EC-112"),
        ("Dr. Harish Balakrishnan", 3, "Professor & HOD", "harish.b@apexuniv.edu.in", "ME-104"),
        ("Prof. Deepak Varma", 4, "Professor & Dean", "deepak.varma@apexuniv.edu.in", "MG-401"),
    ]
    cursor.executemany(
        "INSERT INTO faculty (name, department_id, designation, email, office_room) VALUES (?, ?, ?, ?, ?)",
        faculty_data
    )

    # 3. Subjects
    subjects = [
        ("CS301", "Database Management Systems", 1, 3, 4),
        ("CS302", "Data Structures & Algorithms", 1, 3, 4),
        ("CS303", "Computer Architecture", 1, 3, 3),
        ("CS501", "Artificial Intelligence", 1, 5, 4),
        ("CS502", "Operating Systems", 1, 5, 4),
        ("EC301", "Digital Signal Processing", 2, 3, 4),
        ("MB101", "Marketing Management", 4, 1, 3),
    ]
    cursor.executemany(
        "INSERT INTO subjects (code, name, department_id, semester, credits) VALUES (?, ?, ?, ?, ?)",
        subjects
    )

    # 4. Class Timetables (CSE 3rd Sem)
    class_schedules = [
        (1, 3, "Monday", "09:00 - 10:00 AM", "CS301", "Database Management Systems", "Hall-A 201"),
        (1, 3, "Monday", "10:15 - 11:15 AM", "CS302", "Data Structures & Algorithms", "Hall-A 201"),
        (1, 3, "Monday", "11:30 - 12:30 PM", "CS303", "Computer Architecture", "Hall-A 201"),
        (1, 3, "Monday", "01:30 - 04:30 PM", "CS301L", "DBMS Lab Practical", "Computing Lab 3"),
        (1, 3, "Tuesday", "09:00 - 10:00 AM", "CS302", "Data Structures & Algorithms", "Hall-A 201"),
        (1, 3, "Tuesday", "10:15 - 11:15 AM", "CS301", "Database Management Systems", "Hall-A 201"),
        (1, 3, "Wednesday", "09:00 - 10:00 AM", "CS303", "Computer Architecture", "Hall-A 201"),
        (1, 3, "Thursday", "09:00 - 10:00 AM", "CS301", "Database Management Systems", "Hall-A 201"),
        (1, 3, "Friday", "09:00 - 10:00 AM", "CS302", "Data Structures & Algorithms", "Hall-A 201"),
    ]
    cursor.executemany(
        """
        INSERT INTO class_timetables (department_id, semester, day_of_week, time_slot, subject_code, subject_name, room_no)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        class_schedules
    )

    # 5. Exam Timetables (Upcoming Mid-Term & Semester Exams)
    exam_schedules = [
        (1, 3, "CS301", "Database Management Systems", "2026-10-12", "10:00 AM - 01:00 PM", "Exam Hall 1"),
        (1, 3, "CS302", "Data Structures & Algorithms", "2026-10-14", "10:00 AM - 01:00 PM", "Exam Hall 1"),
        (1, 3, "CS303", "Computer Architecture", "2026-10-16", "10:00 AM - 01:00 PM", "Exam Hall 2"),
        (1, 5, "CS501", "Artificial Intelligence", "2026-10-13", "02:00 PM - 05:00 PM", "Exam Hall 3"),
        (1, 5, "CS502", "Operating Systems", "2026-10-15", "02:00 PM - 05:00 PM", "Exam Hall 3"),
        (2, 3, "EC301", "Digital Signal Processing", "2026-10-12", "10:00 AM - 01:00 PM", "Exam Hall 4"),
    ]
    cursor.executemany(
        """
        INSERT INTO exam_timetables (department_id, semester, subject_code, subject_name, exam_date, time_slot, room_no)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        exam_schedules
    )

    # 6. Notices
    notices = [
        ("End Semester Examination Fee Notice", "Examination", "2026-09-10", "Students must pay the semester examination fee of ₹2,500 by September 30, 2026 via student portal.", 1),
        ("Campus Placement Drive: Google & Microsoft", "Placement", "2026-09-08", "Eligible B.Tech CSE & ECE final year students with CGPA >= 7.5 must register for recruitment drive by Sept 20.", 1),
        ("Annual Cultural Fest 'Tarang 2026' Auditions", "Events", "2026-09-05", "Auditions for music, dance, and drama clubs begin next Monday at University Auditorium.", 1),
        ("Hostel Maintenance & Room Inspection Notice", "Hostel", "2026-09-01", "Annual room sanitization and electricity inspection scheduled for blocks A and B this weekend.", 1),
    ]
    cursor.executemany(
        "INSERT INTO notices (title, category, date_posted, content, active) VALUES (?, ?, ?, ?, ?)",
        notices
    )

    # 7. Sample Students
    students = [
        ("22CS001", "Aarav Sharma", 1, 3, 8.85, 84.5),
        ("22CS045", "Diya Patel", 1, 3, 9.20, 91.0),
        ("22CS078", "Rohan Verma", 1, 3, 6.75, 68.0),
        ("21CS012", "Sneha Kulkarni", 1, 5, 8.40, 82.0),
        ("22EC010", "Kunal Singhania", 2, 3, 7.90, 78.5),
    ]
    cursor.executemany(
        "INSERT INTO students (roll_no, name, department_id, semester, cgpa, attendance_pct) VALUES (?, ?, ?, ?, ?, ?)",
        students
    )

    conn.commit()
    conn.close()
    logger.info("SQLite database successfully seeded with university data!")
