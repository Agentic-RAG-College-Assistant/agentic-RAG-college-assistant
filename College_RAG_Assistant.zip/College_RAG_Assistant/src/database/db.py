"""
SQLite Database Connection and Initialization Module.
Manages database file creation, table initialization, and active connections.
"""

import sqlite3
from pathlib import Path
from src.config import Config
from src.database.models import ALL_TABLES
from src.utils.logger import get_logger

logger = get_logger("DatabaseManager")


def get_db_connection(db_path: Path = Config.DATABASE_PATH) -> sqlite3.Connection:
    """
    Establishes and returns a connection to the SQLite database.
    Sets row_factory to sqlite3.Row for dictionary-like column access.
    """
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    # Enable foreign keys support in SQLite
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def init_db(db_path: Path = Config.DATABASE_PATH) -> None:
    """
    Initializes all SQLite database tables.
    Safe to call multiple times (tables are created IF NOT EXISTS).
    """
    logger.info(f"Initializing SQLite database at: {db_path}")
    conn = get_db_connection(db_path)
    cursor = conn.cursor()

    try:
        for create_sql in ALL_TABLES:
            cursor.execute(create_sql)
        conn.commit()
        logger.info("All SQLite tables initialized successfully.")
    except Exception as e:
        logger.error(f"Failed to initialize SQLite database tables: {e}")
        conn.rollback()
        raise
    finally:
        conn.close()


def get_table_counts(db_path: Path = Config.DATABASE_PATH) -> dict:
    """
    Returns a dictionary of total row counts for all main tables.
    Useful for Admin Panel and system status diagnostics.
    """
    tables = [
        "departments",
        "faculty",
        "subjects",
        "class_timetables",
        "exam_timetables",
        "notices",
        "students",
        "chat_history",
        "uploaded_documents"
    ]
    counts = {}
    conn = get_db_connection(db_path)
    cursor = conn.cursor()

    for table in tables:
        try:
            cursor.execute(f"SELECT COUNT(*) FROM {table}")
            counts[table] = cursor.fetchone()[0]
        except Exception:
            counts[table] = 0

    conn.close()
    return counts
