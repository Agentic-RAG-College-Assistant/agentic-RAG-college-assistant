"""
Modular LLM Service for College Assistant.
Connects to OpenAI-compatible APIs (OpenAI, Groq, Ollama) with an intelligent
offline rule-based fallback for local operation without API keys.
"""

import re
from typing import List, Dict, Any, Optional
from src.config import Config
from src.utils.logger import get_logger

logger = get_logger("LLMService")

try:
    from openai import OpenAI
    _OPENAI_AVAILABLE = True
except ImportError:
    _OPENAI_AVAILABLE = False


class LLMService:
    """Handles prompt construction, hallucination prevention, and response generation."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        model_name: Optional[str] = None
    ):
        self.api_key = api_key if api_key is not None else Config.OPENAI_API_KEY
        self.base_url = base_url or Config.OPENAI_BASE_URL
        self.model_name = model_name or Config.LLM_MODEL
        self.client = None

        if self.api_key and _OPENAI_AVAILABLE:
            try:
                self.client = OpenAI(
                    api_key=self.api_key,
                    base_url=self.base_url,
                    timeout=30.0
                )
                logger.info(f"OpenAI client initialized with model '{self.model_name}'.")
            except Exception as e:
                logger.warning(f"Could not connect to OpenAI API: {e}. Using offline local synthesizer.")
        else:
            logger.info("No API key provided. Using built-in local offline academic response synthesizer.")

    def _offline_synthesizer(
        self,
        query: str,
        retrieved_chunks: List[Dict[str, Any]]
    ) -> str:
        """
        Deterministic, grounded response synthesizer used when running locally offline.
        Extracts verified facts, numbers, dates, rules, and policy statements without hallucinations.
        """
        if not retrieved_chunks:
            return (
                "### ℹ️ Information Not Found in Uploaded Documents\n\n"
                "I could not locate specific records or guidelines regarding your query in the current college documents.\n\n"
                "**Suggestions:**\n"
                "- Verify if the relevant document (syllabus, academic handbook, fee structure) has been uploaded in the Admin Panel.\n"
                "- Try rephrasing your question using official terms (e.g., 'minimum attendance', 'hostel fee', 'grading policy').\n"
                "- Contact the Academic Office or Department HOD for assistance."
            )

        # Combine excerpts
        all_text = "\n\n".join([c.get("text", "") for c in retrieved_chunks])

        # Extract numerical and quantitative facts
        percentages = set(re.findall(r"\b\d+(?:\.\d+)?%", all_text))
        amounts = set(re.findall(r"(?:₹|\$|Rs\.?|INR)\s*[\d,]+(?:\.\d+)?", all_text, re.IGNORECASE))
        dates = set(re.findall(r"\b\d{1,2}(?:st|nd|rd|th)?\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s*\d{2,4}?", all_text, re.IGNORECASE))

        lines = [
            f"### Verified Information: *\"{query}\"*\n",
            "Based on the official college documents currently on file, here are the verified details:\n"
        ]

        if percentages or amounts or dates:
            lines.append("**Key Figures & Policies Extracted:**")
            if percentages:
                lines.append(f"- **Percentages / Thresholds:** {', '.join(sorted(percentages))}")
            if amounts:
                lines.append(f"- **Fees / Financial Figures:** {', '.join(sorted(amounts))}")
            if dates:
                lines.append(f"- **Key Dates / Deadlines:** {', '.join(sorted(dates))}")
            lines.append("")

        lines.append("**Relevant Document Excerpt:**")
        # Format up to top 2 most relevant passages
        for i, chunk in enumerate(retrieved_chunks[:2], start=1):
            src = chunk.get("source", "Document")
            pg = chunk.get("page", 1)
            txt = chunk.get("text", "").strip()
            if len(txt) > 350:
                txt = txt[:350] + "..."
            lines.append(f"> **[{i}] Source: {src} (Page {pg}):**\n> \"{txt}\"\n")

        lines.append("---")
        lines.append("*Note: The above information is strictly referenced from uploaded college publications.*")

        return "\n".join(lines)

    def generate_response(
        self,
        query: str,
        retrieved_chunks: List[Dict[str, Any]],
        conversation_history: Optional[List[Dict[str, str]]] = None
    ) -> str:
        """
        Generates a student-facing response grounded strictly in retrieved chunks.
        """
        if not retrieved_chunks:
            return self._offline_synthesizer(query, [])

        if self.client is None:
            return self._offline_synthesizer(query, retrieved_chunks)

        # Build context block
        context_parts = []
        for idx, chunk in enumerate(retrieved_chunks, start=1):
            source = chunk.get("source", "Document")
            page = chunk.get("page", 1)
            context_parts.append(f"[Excerpt {idx} - Source: {source}, Page: {page}]\n{chunk.get('text', '')}")

        context_str = "\n\n".join(context_parts)

        system_prompt = (
            "You are the official AI College Assistant for university students and faculty. "
            "Your tone is polite, academic, precise, and encouraging.\n"
            "STRICT GROUNDING RULES:\n"
            "1. Answer ONLY using the provided document excerpts below.\n"
            "2. Never hallucinate or invent college rules, fee amounts, dates, or grades.\n"
            "3. Cite the document source and page number inline (e.g. '[Academic_Rules.pdf, Page 3]').\n"
            "4. If the excerpts do not contain enough information to answer the question, clearly state "
            "that the information is not available in the current college documents."
        )

        user_prompt = f"""STUDENT QUESTION:
{query}

RETRIEVED COLLEGE DOCUMENT CONTEXT:
{context_str}

Please provide a clear, well-structured response to the student's question:"""

        messages = [{"role": "system", "content": system_prompt}]

        if conversation_history:
            for turn in conversation_history[-4:]:
                messages.append({"role": turn.get("role", "user"), "content": turn.get("content", "")})

        messages.append({"role": "user", "content": user_prompt})

        try:
            response = self.client.chat.completions.create(
                model=self.model_name,
                messages=messages,
                temperature=Config.LLM_TEMPERATURE,
                max_tokens=Config.LLM_MAX_TOKENS
            )
            return response.choices[0].message.content or ""
        except Exception as e:
            logger.warning(f"LLM generation failed: {e}. Falling back to offline synthesizer.")
            return self._offline_synthesizer(query, retrieved_chunks)
