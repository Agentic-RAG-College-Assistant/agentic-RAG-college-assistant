"""
Logging Framework for the College Assistant.
Provides clean console logging and automatic rotating file logging in logs/app.log.
"""

import sys
import logging
from logging.handlers import RotatingFileHandler
from src.config import Config

# Format: [2026-09-16 11:30:00] - [INFO] - [ModuleName:Line] - Message
LOG_FORMAT = "[%(asctime)s] - [%(levelname)s] - [%(name)s:%(lineno)d] - %(message)s"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


def get_logger(name: str = "CollegeAssistant") -> logging.Logger:
    """
    Returns a configured logger for any module.
    
    Args:
        name: The name of the module calling the logger (usually __name__).
    """
    logger = logging.getLogger(name)

    # Avoid adding duplicate handlers if the logger already has them
    if logger.hasHandlers():
        return logger

    level = getattr(logging, Config.LOG_LEVEL.upper(), logging.INFO)
    logger.setLevel(level)

    formatter = logging.Formatter(LOG_FORMAT, datefmt=DATE_FORMAT)

    # 1. Console Output Handler (prints to terminal/Powershell)
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    # 2. Rotating File Handler (saves up to 5 MB per file, keeps 3 backup files)
    try:
        file_handler = RotatingFileHandler(
            filename=str(Config.LOG_FILE),
            maxBytes=5 * 1024 * 1024,
            backupCount=3,
            encoding="utf-8"
        )
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    except Exception as e:
        print(f"Warning: Could not initialize log file: {e}", file=sys.stderr)

    logger.propagate = False
    return logger
