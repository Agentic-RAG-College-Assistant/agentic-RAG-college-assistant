"""
Helper Functions for text cleaning, input sanitization, and citation formatting.
"""

import re
import html
from typing import List, Dict, Any


def clean_text(text: str) -> str:
    """
    Cleans extracted text by removing extra spaces, linebreaks, and non-printable characters.
    """
    if not text:
        return ""

    # Replace null bytes and non-breaking spaces
    text = text.replace("\x00", " ").replace("\u00a0", " ")

    # Collapse multiple spaces or tabs into a single space
    text = re.sub(r"[ \t]+", " ", text)

    # Collapse three or more newlines into two
    text = re.sub(r"\n\s*\n+", "\n\n", text)

    return text.strip()


def sanitize_query(query: str) -> str:
    """
    Sanitizes user input to prevent prompt injection and remove malformed characters.
    """
    if not query:
        return ""

    # Unescape HTML characters
    query = html.unescape(query)

    # Remove dangerous prompt injection tokens
    query = re.sub(r"(<\|.*?\|>|\[INST\]|\[/INST\]|<system>|<user>|<assistant>)", "", query)

    # Strip excess whitespace
    query = re.sub(r"\s+", " ", query)

    return query.strip()


def format_source_citation(source_name: str, page: int = 1) -> str:
    """
    Formats a clean, standardized citation string for students.
    Example: 'Academic_Regulations.pdf — Page 12'
    """
    clean_name = str(source_name).replace("\\", "/").split("/")[-1]
    if page:
        return f"{clean_name} — Page {page}"
    return clean_name


def format_latency(seconds: float) -> str:
    """
    Converts elapsed time into human-friendly format (ms or s).
    """
    if seconds < 1.0:
        return f"{seconds * 1000:.0f} ms"
    return f"{seconds:.2f} s"


def format_file_size(size_in_bytes: int) -> str:
    """
    Converts raw bytes to human-readable size (KB or MB).
    """
    if size_in_bytes < 1024:
        return f"{size_in_bytes} B"
    elif size_in_bytes < 1024 * 1024:
        return f"{size_in_bytes / 1024:.1f} KB"
    else:
        return f"{size_in_bytes / (1024 * 1024):.2f} MB"
