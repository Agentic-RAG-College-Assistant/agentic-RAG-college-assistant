"""Utility functions and logger package."""
