"""
College Query Preprocessing & Vector Retriever.
Expands academic abbreviations (CGPA, CTC, HOD) to boost semantic recall in ChromaDB.
"""

import re
from typing import List, Dict, Any, Optional
from src.config import Config
from src.retrieval.vector_store import ChromaVectorStore
from src.utils.helpers import sanitize_query
from src.utils.logger import get_logger

logger = get_logger("Retriever")

# Mapping of college abbreviations to semantic keywords
COLLEGE_ACRONYMS = {
    r"\bcgpa\b": "CGPA cumulative grade point average grading criteria marks",
    r"\bsgpa\b": "SGPA semester grade point average credits",
    r"\bhod\b": "Head of Department HOD faculty office contact",
    r"\bplacement\b|\bplacements\b|\bctc\b|\bpackage\b": "campus placement job recruitment package CTC salary highest average top recruiters",
    r"\battendance\b|\bshortage\b|\bdetain\b|\bdetention\b": "attendance percentage requirement 75 percent medical leave condonation detention barred",
    r"\bscholarship\b|\bscholarships\b": "merit scholarship tuition fee waiver concession financial assistance Dean Fellowship",
    r"\bfee\b|\bfees\b": "tuition fee hostel mess charges payment deadline refund policy",
    r"\bhostel\b|\bmess\b": "hostel accommodation rooms mess food facilities warden rules curfew",
    r"\bbacklog\b|\barrear\b|\bsupplementary\b": "backlog re-examination supplementary exam arrear revaluation grading",
    r"\badmission\b|\badmissions\b": "admission eligibility criteria entrance cutoff counseling application procedure",
    r"\bsyllabus\b|\bcourse\b": "syllabus curriculum course subjects credits modules units",
}


class CollegeRetriever:
    """Handles query expansion and similarity retrieval over ChromaDB."""

    def __init__(self, vector_store: Optional[ChromaVectorStore] = None):
        self.vector_store = vector_store or ChromaVectorStore()

    def expand_query(self, query: str) -> str:
        """Enriches queries with academic domain terminology."""
        lowered = query.lower()
        expanded_terms = []

        for pattern, expansion in COLLEGE_ACRONYMS.items():
            if re.search(pattern, lowered):
                expanded_terms.append(expansion)

        if expanded_terms:
            enriched = f"{query} ({' '.join(expanded_terms[:2])})"
            logger.info(f"Query enriched: '{query}' -> '{enriched}'")
            return enriched

        return query

    def retrieve(
        self,
        query: str,
        top_k: Optional[int] = None,
        score_threshold: Optional[float] = None
    ) -> List[Dict[str, Any]]:
        """
        Retrieves top relevant chunks from ChromaDB.
        
        Args:
            query: Student's inquiry.
            top_k: Number of chunks to retrieve.
            score_threshold: Minimum similarity score filter.
            
        Returns:
            List[Dict[str, Any]]: Ranked list of matching chunks with source metadata.
        """
        cleaned = sanitize_query(query)
        if not cleaned:
            return []

        top_k = top_k or Config.TOP_K_RESULTS
        threshold = score_threshold if score_threshold is not None else Config.SIMILARITY_THRESHOLD

        # Step 1: Direct query search
        direct_matches = self.vector_store.similarity_search(cleaned, top_k=top_k, score_threshold=threshold)

        # Step 2: Expanded query search if terms were found
        expanded = self.expand_query(cleaned)
        if expanded != cleaned:
            expanded_matches = self.vector_store.similarity_search(expanded, top_k=top_k, score_threshold=threshold)
        else:
            expanded_matches = []

        # Deduplicate results by chunk ID or text prefix
        seen = set()
        merged: List[Dict[str, Any]] = []

        for chunk in sorted(direct_matches + expanded_matches, key=lambda x: x.get("similarity_score", 0.0), reverse=True):
            cid = chunk.get("id") or chunk.get("text", "")[:60]
            if cid not in seen:
                seen.add(cid)
                merged.append(chunk)

        final_chunks = merged[:top_k]
        logger.info(f"Retriever selected {len(final_chunks)} unique chunks for query: '{cleaned}'")
        return final_chunks
