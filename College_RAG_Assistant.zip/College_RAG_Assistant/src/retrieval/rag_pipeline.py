"""
Complete RAG Pipeline Module.
Combines ChromaDB vector retrieval, context formatting, LLM response generation,
and traceable source citations.
"""

import time
from typing import Dict, Any, List, Optional
from src.retrieval.retriever import CollegeRetriever
from src.llm.llm_service import LLMService
from src.utils.logger import get_logger

logger = get_logger("RAGPipeline")


class RAGPipeline:
    """Coordinates Document Retrieval and Answer Generation with source citations."""

    def __init__(
        self,
        retriever: Optional[CollegeRetriever] = None,
        llm_service: Optional[LLMService] = None
    ):
        self.retriever = retriever or CollegeRetriever()
        self.llm_service = llm_service or LLMService()

    def answer_query(
        self,
        query: str,
        conversation_history: Optional[List[Dict[str, str]]] = None,
        top_k: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Executes full RAG workflow for a student question.
        
        Returns:
            Dict containing answer, source citations, chunks retrieved, and elapsed time.
        """
        start_time = time.time()
        logger.info(f"--- RAG Pipeline Processing Query: '{query}' ---")

        # 1. Retrieve relevant chunks from ChromaDB
        chunks = self.retriever.retrieve(query=query, top_k=top_k)

        # 2. Generate response using LLM or offline synthesizer
        answer = self.llm_service.generate_response(
            query=query,
            retrieved_chunks=chunks,
            conversation_history=conversation_history
        )

        # 3. Build deduplicated source citations
        sources = []
        seen = set()
        for c in chunks:
            source = c.get("source", "College Document")
            page = c.get("page", 1)
            key = (source, page)
            if key not in seen:
                seen.add(key)
                snippet = c.get("text", "").replace("\n", " ").strip()
                if len(snippet) > 180:
                    snippet = snippet[:180] + "..."
                sources.append({
                    "source": source,
                    "page": page,
                    "snippet": snippet,
                    "similarity_score": c.get("similarity_score", 0.0)
                })

        elapsed = round(time.time() - start_time, 3)
        logger.info(f"RAG answer generated in {elapsed}s with {len(sources)} unique citation(s).")

        return {
            "query": query,
            "answer": answer,
            "sources": sources,
            "chunks_found": len(chunks),
            "latency_seconds": elapsed,
            "tool_used": "RAG_RETRIEVAL"
        }
