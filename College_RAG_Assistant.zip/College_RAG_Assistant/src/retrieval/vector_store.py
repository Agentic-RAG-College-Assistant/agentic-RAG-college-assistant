"""
ChromaDB Vector Store Manager.
Manages persistent ChromaDB vector collections, embedding insertions,
metadata filtering, and semantic similarity retrieval.
"""

from pathlib import Path
from typing import List, Dict, Any, Optional
import chromadb
from chromadb.config import Settings
from src.config import Config
from src.ingestion.text_chunker import DocumentChunk
from src.ingestion.embedding_service import EmbeddingService
from src.utils.logger import get_logger

logger = get_logger("ChromaVectorStore")


class ChromaVectorStore:
    """Persistent ChromaDB client and collection management wrapper."""

    def __init__(
        self,
        persist_dir: Optional[Path] = None,
        collection_name: Optional[str] = None,
        embedding_service: Optional[EmbeddingService] = None
    ):
        self.persist_dir = persist_dir or Config.CHROMA_DIR
        self.persist_dir.mkdir(parents=True, exist_ok=True)
        self.collection_name = collection_name or Config.CHROMA_COLLECTION_NAME
        self.embedding_service = embedding_service or EmbeddingService()

        logger.info(f"Connecting to ChromaDB at: {self.persist_dir}")
        self.client = chromadb.PersistentClient(
            path=str(self.persist_dir),
            settings=Settings(anonymized_telemetry=False)
        )

        # Get or create the vector collection with cosine similarity
        self.collection = self.client.get_or_create_collection(
            name=self.collection_name,
            metadata={"hnsw:space": "cosine"}
        )
        logger.info(f"ChromaDB collection '{self.collection_name}' ready. Count: {self.collection.count()}")

    def add_chunks(self, chunks: List[DocumentChunk]) -> int:
        """
        Embeds and stores text chunks into ChromaDB collection with metadata.
        
        Args:
            chunks: List of DocumentChunk instances.
            
        Returns:
            int: Number of chunks added.
        """
        if not chunks:
            return 0

        texts = [chunk.text for chunk in chunks]
        metadatas = [chunk.metadata for chunk in chunks]
        ids = [
            chunk.metadata.get("chunk_id") or f"chunk_{i}"
            for i, chunk in enumerate(chunks)
        ]

        logger.info(f"Generating embeddings for {len(texts)} chunks...")
        embeddings = self.embedding_service.embed_texts(texts)

        logger.info(f"Upserting {len(texts)} chunks into ChromaDB '{self.collection_name}'...")
        self.collection.upsert(
            ids=ids,
            embeddings=embeddings,
            documents=texts,
            metadatas=metadatas
        )

        logger.info(f"Successfully upserted {len(chunks)} chunks. Total collection size: {self.collection.count()}")
        return len(chunks)

    def similarity_search(
        self,
        query: str,
        top_k: Optional[int] = None,
        score_threshold: Optional[float] = None
    ) -> List[Dict[str, Any]]:
        """
        Performs semantic similarity retrieval for a given query string.
        
        Args:
            query: The question or search terms.
            top_k: Maximum number of top chunks to return.
            score_threshold: Minimum similarity score (0.0 to 1.0).
            
        Returns:
            List[Dict[str, Any]]: List of matching results sorted by similarity.
        """
        top_k = top_k or Config.TOP_K_RESULTS
        score_threshold = score_threshold if score_threshold is not None else Config.SIMILARITY_THRESHOLD

        total_count = self.collection.count()
        if total_count == 0:
            return []

        actual_k = min(top_k, total_count)
        query_vector = self.embedding_service.embed_query(query)

        results = self.collection.query(
            query_embeddings=[query_vector],
            n_results=actual_k,
            include=["documents", "metadatas", "distances"]
        )

        formatted_results: List[Dict[str, Any]] = []

        docs = results.get("documents", [[]])[0]
        metas = results.get("metadatas", [[]])[0]
        distances = results.get("distances", [[]])[0]
        ids = results.get("ids", [[]])[0]

        for doc_text, meta, dist, cid in zip(docs, metas, distances, ids):
            # For cosine distance, similarity = 1.0 - distance
            similarity_score = max(0.0, round(1.0 - float(dist), 4))

            if similarity_score >= score_threshold:
                formatted_results.append({
                    "id": cid,
                    "text": doc_text,
                    "metadata": meta,
                    "similarity_score": similarity_score,
                    "source": meta.get("source", "Unknown Document"),
                    "page": meta.get("page", 1)
                })

        logger.info(f"Retrieved {len(formatted_results)} chunks for query: '{query[:40]}...' (threshold: {score_threshold})")
        return formatted_results

    def delete_document(self, filename: str) -> int:
        """
        Deletes all chunks belonging to a given document filename.
        
        Returns:
            int: Remaining collection count.
        """
        try:
            self.collection.delete(where={"source": filename})
            logger.info(f"Deleted document '{filename}' from ChromaDB.")
            return self.collection.count()
        except Exception as e:
            logger.error(f"Failed to delete '{filename}' from ChromaDB: {e}")
            return self.collection.count()

    def clear(self):
        """Empties all vectors from the collection."""
        try:
            self.client.delete_collection(self.collection_name)
            self.collection = self.client.get_or_create_collection(
                name=self.collection_name,
                metadata={"hnsw:space": "cosine"}
            )
            logger.info(f"Collection '{self.collection_name}' cleared.")
        except Exception as e:
            logger.error(f"Failed to clear Chroma collection: {e}")

    def get_stats(self) -> Dict[str, Any]:
        """Returns statistics of the vector database."""
        total_chunks = self.collection.count()
        sources = set()

        if total_chunks > 0:
            # Fetch metadata of all records to compute unique sources
            records = self.collection.get(include=["metadatas"])
            metas = records.get("metadatas", [])
            for m in metas:
                if m and "source" in m:
                    sources.add(m["source"])

        return {
            "total_chunks": total_chunks,
            "total_documents": len(sources),
            "document_sources": sorted(list(sources)),
            "collection_name": self.collection_name,
            "vector_dimension": self.embedding_service.dimension,
            "storage_path": str(self.persist_dir)
        }
