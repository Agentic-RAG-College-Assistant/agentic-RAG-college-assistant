"""
Agent Tools Registry for College Assistant.
Implements individual specialized tools for querying SQLite structured data and ChromaDB documents.
"""

from typing import Dict, Any, Optional, List
from src.database import crud
from src.retrieval.rag_pipeline import RAGPipeline
from src.utils.logger import get_logger

logger = get_logger("AgentTools")


def class_timetable_tool(
    department: Optional[str] = None,
    semester: Optional[int] = None,
    day: Optional[str] = None
) -> Dict[str, Any]:
    """Queries SQLite for weekly lecture schedule."""
    # Defaults: CSE semester 3 Monday if none provided
    dept = department or "CSE"
    sem = semester or 3
    day_name = day or "Monday"

    records = crud.get_class_timetable(dept_code=dept, semester=sem, day_of_week=day_name)
    if not records:
        # Try fetching without day filter if specific day yielded none
        records = crud.get_class_timetable(dept_code=dept, semester=sem)

    if not records:
        text = f"No class timetable found for Department **{dept}** (Semester {sem}). Please check department code."
    else:
        lines = [f"### 📅 Class Schedule — {dept} (Semester {sem})"]
        current_day = None
        for r in records:
            if r["day_of_week"] != current_day:
                current_day = r["day_of_week"]
                lines.append(f"\n**{current_day}:**")
            lines.append(f"- **{r['time_slot']}**: {r['subject_name']} (`{r['subject_code']}`) — *Room: {r['room_no']}*")
        text = "\n".join(lines)

    return {
        "text": text,
        "records_found": len(records),
        "tool_name": "SQLite Class Timetable Tool",
        "sources": [{"source": "college.db (class_timetables)", "page": 1, "snippet": f"{dept} Sem {sem} Schedule"}]
    }


def exam_timetable_tool(
    department: Optional[str] = None,
    semester: Optional[int] = None
) -> Dict[str, Any]:
    """Queries SQLite for upcoming semester examinations."""
    dept = department or "CSE"
    sem = semester or 3

    records = crud.get_exam_timetable(dept_code=dept, semester=sem)
    if not records:
        # Fallback to all upcoming exams
        records = crud.get_exam_timetable()

    if not records:
        text = f"No upcoming examination schedule found for Department **{dept}**."
    else:
        lines = [f"### 📝 Examination Timetable — {dept} (Semester {sem})\n"]
        for r in records:
            lines.append(
                f"- **{r['exam_date']}** ({r['time_slot']}): "
                f"**{r['subject_name']}** (`{r['subject_code']}`) — *Location: {r['room_no']}*"
            )
        text = "\n".join(lines)

    return {
        "text": text,
        "records_found": len(records),
        "tool_name": "SQLite Exam Timetable Tool",
        "sources": [{"source": "college.db (exam_timetables)", "page": 1, "snippet": f"{dept} Exam Schedule"}]
    }


def faculty_info_tool(query: str, department: Optional[str] = None) -> Dict[str, Any]:
    """Queries SQLite for faculty directory and HOD details."""
    # Look for names or HOD
    dept = department
    keyword = None
    if "hod" in query.lower() or "head" in query.lower():
        keyword = "HOD"
    else:
        # Extract potential professor name
        for word in query.split():
            if len(word) > 3 and word.lower() not in ["who", "what", "email", "office", "faculty", "professor", "teacher"]:
                keyword = word
                break

    records = crud.get_faculty(keyword=keyword, dept_code=dept)
    if not records and dept:
        records = crud.get_faculty(dept_code=dept)
    elif not records:
        records = crud.get_faculty()[:5]

    if not records:
        text = "No matching faculty members found in the university database."
    else:
        lines = ["### 👥 Faculty & Department Directory\n"]
        for f in records:
            lines.append(
                f"- **{f['name']}** — *{f['designation']}*, Dept of {f['dept_name']} (`{f['dept_code']}`)\n"
                f"  • **Email:** `{f['email']}`\n"
                f"  • **Office:** {f['office_room']}"
            )
        text = "\n".join(lines)

    return {
        "text": text,
        "records_found": len(records),
        "tool_name": "SQLite Faculty Directory Tool",
        "sources": [{"source": "college.db (faculty)", "page": 1, "snippet": "Official Faculty Directory"}]
    }


def notice_tool(category: Optional[str] = None) -> Dict[str, Any]:
    """Queries SQLite for recent college notices and circulars."""
    records = crud.get_notices(category=category, limit=5)
    if not records:
        text = "No active college notices found at this time."
    else:
        lines = ["### 📢 Official College Notices & Circulars\n"]
        for n in records:
            lines.append(
                f"#### 📌 {n['title']} ({n['date_posted']})\n"
                f"**Category:** *{n['category']}*\n\n"
                f"{n['content']}\n"
            )
        text = "\n".join(lines)

    return {
        "text": text,
        "records_found": len(records),
        "tool_name": "SQLite Notices Tool",
        "sources": [{"source": "college.db (notices)", "page": 1, "snippet": "Recent College Circulars"}]
    }


def student_info_tool(roll_no: Optional[str] = None) -> Dict[str, Any]:
    """Queries SQLite for individual student attendance and CGPA."""
    target_roll = roll_no or "22CS001"
    student = crud.get_student_info(target_roll)

    if not student:
        text = f"No student record found matching roll number **{target_roll}**."
    else:
        text = (
            f"### 🧑‍🎓 Student Academic Record\n\n"
            f"- **Roll Number:** `{student['roll_no']}`\n"
            f"- **Student Name:** {student['name']}\n"
            f"- **Department:** {student['dept_name']} (`{student['dept_code']}`)\n"
            f"- **Current Semester:** Semester {student['semester']}\n"
            f"- **Cumulative GPA (CGPA):** **{student['cgpa']:.2f}**\n"
            f"- **Current Attendance:** **{student['attendance_pct']:.1f}%** "
            f"({'✅ Eligible' if student['attendance_pct'] >= 75.0 else '⚠️ Shortage Risk'})\n"
        )

    return {
        "text": text,
        "records_found": 1 if student else 0,
        "tool_name": "SQLite Student Information Tool",
        "sources": [{"source": "college.db (students)", "page": 1, "snippet": f"Record for {target_roll}"}]
    }


def greeting_tool() -> Dict[str, Any]:
    """Generates a friendly introductory greeting."""
    text = (
        "### 🎓 Welcome to Apex University AI Assistant!\n\n"
        "I am your Agentic College Assistant equipped with both structured university records and document retrieval capabilities.\n\n"
        "**What I can help you with:**\n"
        "- 📅 **Class Timetables** (*e.g., 'What is Monday's schedule for CSE 3rd sem?'*)\n"
        "- 📝 **Exam Schedules** (*e.g., 'When are the 3rd semester CSE examinations?'*)\n"
        "- 👥 **Faculty & HOD Contacts** (*e.g., 'Who is the HOD of Computer Science?'*)\n"
        "- 📢 **Notices & Circulars** (*e.g., 'Show recent college notices'*)\n"
        "- 🧑‍🎓 **Student Records** (*e.g., 'Check attendance for roll number 22CS001'*)\n"
        "- 📚 **Academic Regulations & Policies** (*e.g., 'What is the 75% attendance rule and detention policy?'*)\n"
        "- 💰 **Fee Structures & Scholarships** (*e.g., 'What are the tuition fees and Dean's scholarship criteria?'*)\n\n"
        "How can I assist you today?"
    )
    return {
        "text": text,
        "records_found": 1,
        "tool_name": "System Greeting Tool",
        "sources": []
    }
