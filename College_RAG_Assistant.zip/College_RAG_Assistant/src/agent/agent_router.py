"""
Agent Router Module.
Analyzes student queries, determines intent, extracts query parameters,
and selects the appropriate tool workflow (SQLite Database vs. ChromaDB Document RAG).
"""

import re
from typing import Dict, Any, Tuple
from src.utils.logger import get_logger

logger = get_logger("AgentRouter")

# Intent Categories
INTENT_EXAM_TIMETABLE = "EXAM_TIMETABLE"
INTENT_CLASS_TIMETABLE = "CLASS_TIMETABLE"
INTENT_FACULTY_INFO = "FACULTY_INFO"
INTENT_NOTICES = "NOTICES"
INTENT_STUDENT_INFO = "STUDENT_INFO"
INTENT_DOCUMENT_RAG = "DOCUMENT_RAG"
INTENT_GREETING = "GREETING"


class AgentRouter:
    """Classifies user inquiries and extracts entities for tool routing."""

    def __init__(self):
        logger.info("Initialized Agent Router.")

    def extract_entities(self, query: str) -> Dict[str, Any]:
        """
        Extracts department, semester, day of week, and roll number if mentioned.
        """
        entities = {
            "department": None,
            "semester": None,
            "day": None,
            "roll_no": None
        }
        lowered = query.lower()

        # 1. Department detection
        if re.search(r"\b(?:cse|computer science|computing)\b", lowered):
            entities["department"] = "CSE"
        elif re.search(r"\b(?:ece|electronics)\b", lowered):
            entities["department"] = "ECE"
        elif re.search(r"\b(?:mech|mechanical)\b", lowered):
            entities["department"] = "MECH"
        elif re.search(r"\b(?:mba|management)\b", lowered):
            entities["department"] = "MBA"

        # 2. Semester detection (e.g. '3rd sem', 'semester 5', 'sem 3')
        sem_match = re.search(r"\b(?:sem|semester)\s*([1-8])\b|\b([1-8])(?:st|nd|rd|th)?\s*(?:sem|semester)\b", lowered)
        if sem_match:
            entities["semester"] = int(sem_match.group(1) or sem_match.group(2))

        # 3. Day of week detection
        days = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
        for day in days:
            if re.search(rf"\b{day}\b", lowered):
                entities["day"] = day.capitalize()
                break

        # 4. Roll number detection (e.g. 22CS001, 21EC010)
        roll_match = re.search(r"\b\d{2}[A-Za-z]{2,3}\d{3}\b", query)
        if roll_match:
            entities["roll_no"] = roll_match.group(0).upper()

        return entities

    def route_query(self, query: str) -> Tuple[str, Dict[str, Any]]:
        """
        Determines the intent and parameters for a student query.
        
        Returns:
            Tuple[str, Dict[str, Any]]: (intent_name, extracted_entities)
        """
        q_clean = query.strip()
        lowered = q_clean.lower()
        entities = self.extract_entities(q_clean)

        # 1. Greeting
        if re.match(r"^(hi|hello|hey|good\s+(morning|afternoon|evening)|help)\b", lowered):
            return INTENT_GREETING, entities

        # 2. Student Info (Specific Roll Number mentioned)
        if entities.get("roll_no") or re.search(r"\b(my attendance|my cgpa|student profile|student details)\b", lowered):
            return INTENT_STUDENT_INFO, entities

        # 3. Exam Timetable
        if re.search(r"\b(exam|examination|mid-term|end-semester|finals?)\s*(timetable|schedule|dates?|timing)\b", lowered) or \
           re.search(r"\b(when is the exam|exam schedule)\b", lowered):
            return INTENT_EXAM_TIMETABLE, entities

        # 4. Class Timetable / Routine
        if re.search(r"\b(class|lecture|routine|period)\s*(timetable|schedule|timing)\b", lowered) or \
           re.search(r"\b(what classes? on|schedule for monday|timetable for)\b", lowered) or \
           (entities.get("day") and re.search(r"\b(class|timetable|classes)\b", lowered)):
            return INTENT_CLASS_TIMETABLE, entities

        # 5. Faculty / HOD / Professor
        if re.search(r"\b(faculty|professor|teacher|hod|head of department|who teaches|office room|email of|contact of)\b", lowered):
            return INTENT_FACULTY_INFO, entities

        # 6. Notices / Announcements
        if re.search(r"\b(notice|notices|announcement|circular|latest news|event|fest)\b", lowered):
            return INTENT_NOTICES, entities

        # 7. Default to Document RAG (Academic Regulations, Syllabus, Fees, Placements, Rules)
        return INTENT_DOCUMENT_RAG, entities
