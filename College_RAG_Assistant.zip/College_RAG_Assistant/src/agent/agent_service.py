"""
Master Agent Service.
Orchestrates the Agentic RAG workflow:
Student Query -> Agent Router -> Tool Selection -> Execution (SQLite or ChromaDB) -> Citation Assembly -> Memory Logging.
"""

import time
from typing import Dict, Any, Optional, List
from src.agent.agent_router import (
    AgentRouter,
    INTENT_EXAM_TIMETABLE,
    INTENT_CLASS_TIMETABLE,
    INTENT_FACULTY_INFO,
    INTENT_NOTICES,
    INTENT_STUDENT_INFO,
    INTENT_DOCUMENT_RAG,
    INTENT_GREETING
)
from src.agent import tools
from src.retrieval.rag_pipeline import RAGPipeline
from src.database import crud
from src.utils.logger import get_logger

logger = get_logger("AgentService")


class CollegeAgentService:
    """Central agent coordinator responsible for intent routing, tool execution, and memory."""

    def __init__(
        self,
        router: Optional[AgentRouter] = None,
        rag_pipeline: Optional[RAGPipeline] = None
    ):
        self.router = router or AgentRouter()
        self.rag_pipeline = rag_pipeline or RAGPipeline()
        logger.info("CollegeAgentService initialized.")

    def handle_query(
        self,
        query: str,
        session_id: str = "default_session",
        conversation_history: Optional[List[Dict[str, str]]] = None
    ) -> Dict[str, Any]:
        """
        Executes the agentic workflow for a student query.
        
        Args:
            query: The question asked by the student.
            session_id: Session identifier for conversational memory.
            conversation_history: In-memory chat history from UI.
            
        Returns:
            Dict containing answer, source citations, tool used, and latency.
        """
        start_time = time.time()
        logger.info(f"--- Processing Query (Session: {session_id}): '{query}' ---")

        # Step 1: Agent Router Intent & Entity Classification
        intent, entities = self.router.route_query(query)
        logger.info(f"Agent Router classified intent as '{intent}' with entities: {entities}")

        # Step 2: Tool Dispatch & Execution
        sources = []
        tool_used = "Unknown"

        if intent == INTENT_GREETING:
            tool_res = tools.greeting_tool()
            answer = tool_res["text"]
            tool_used = tool_res["tool_name"]

        elif intent == INTENT_CLASS_TIMETABLE:
            tool_res = tools.class_timetable_tool(
                department=entities.get("department"),
                semester=entities.get("semester"),
                day=entities.get("day")
            )
            answer = tool_res["text"]
            tool_used = tool_res["tool_name"]
            sources = tool_res["sources"]

        elif intent == INTENT_EXAM_TIMETABLE:
            tool_res = tools.exam_timetable_tool(
                department=entities.get("department"),
                semester=entities.get("semester")
            )
            answer = tool_res["text"]
            tool_used = tool_res["tool_name"]
            sources = tool_res["sources"]

        elif intent == INTENT_FACULTY_INFO:
            tool_res = tools.faculty_info_tool(
                query=query,
                department=entities.get("department")
            )
            answer = tool_res["text"]
            tool_used = tool_res["tool_name"]
            sources = tool_res["sources"]

        elif intent == INTENT_NOTICES:
            tool_res = tools.notice_tool()
            answer = tool_res["text"]
            tool_used = tool_res["tool_name"]
            sources = tool_res["sources"]

        elif intent == INTENT_STUDENT_INFO:
            tool_res = tools.student_info_tool(roll_no=entities.get("roll_no"))
            answer = tool_res["text"]
            tool_used = tool_res["tool_name"]
            sources = tool_res["sources"]

        else:
            # INTENT_DOCUMENT_RAG: Queries ChromaDB vector store
            rag_res = self.rag_pipeline.answer_query(
                query=query,
                conversation_history=conversation_history
            )
            answer = rag_res["answer"]
            sources = rag_res["sources"]
            tool_used = "ChromaDB Document RAG Pipeline"

        elapsed = round(time.time() - start_time, 3)

        # Step 3: Persist Conversation Turn into SQLite
        try:
            crud.add_chat_message(session_id=session_id, role="user", content=query, tool_used=tool_used)
            crud.add_chat_message(session_id=session_id, role="assistant", content=answer, tool_used=tool_used)
        except Exception as e:
            logger.warning(f"Failed to log chat turn into SQLite: {e}")

        logger.info(f"Agent finished response in {elapsed}s using tool '{tool_used}'.")

        return {
            "query": query,
            "answer": answer,
            "sources": sources,
            "intent": intent,
            "entities": entities,
            "tool_used": tool_used,
            "latency_seconds": elapsed
        }
