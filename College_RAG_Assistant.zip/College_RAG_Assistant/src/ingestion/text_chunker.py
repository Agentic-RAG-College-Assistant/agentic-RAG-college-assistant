"""
Text Chunking Module for Document Processing.
Splits text recursively using paragraphs, sentences, and words to preserve semantic context.
"""

from typing import List, Dict, Any, Optional
from src.config import Config
from src.ingestion.document_loader import Document
from src.utils.logger import get_logger

logger = get_logger("TextChunker")


class DocumentChunk:
    """Represents an individual text chunk ready for vector embedding."""

    def __init__(self, text: str, metadata: Dict[str, Any]):
        self.text = text
        self.metadata = metadata

    def to_dict(self) -> Dict[str, Any]:
        return {
            "text": self.text,
            "metadata": self.metadata
        }

    def __repr__(self):
        source = self.metadata.get("source", "doc")
        cid = self.metadata.get("chunk_id", "")
        return f"<DocumentChunk id='{cid}' source='{source}' chars={len(self.text)}>"


class TextChunker:
    """
    Splits Document objects into overlapping chunks using recursive boundaries.
    """

    DEFAULT_SEPARATORS = ["\n\n", "\n", ". ", "? ", "! ", "; ", " ", ""]

    def __init__(
        self,
        chunk_size: Optional[int] = None,
        chunk_overlap: Optional[int] = None
    ):
        self.chunk_size = chunk_size or Config.CHUNK_SIZE
        self.chunk_overlap = chunk_overlap or Config.CHUNK_OVERLAP

        if self.chunk_overlap >= self.chunk_size:
            raise ValueError("chunk_overlap must be smaller than chunk_size.")

    def _split_text(self, text: str, separators: List[str]) -> List[str]:
        """Recursively splits text on the highest available separator."""
        final_pieces: List[str] = []
        separator = separators[-1]
        remaining_separators = []

        for i, sep in enumerate(separators):
            if sep == "":
                separator = ""
                break
            if sep in text:
                separator = sep
                remaining_separators = separators[i + 1:]
                break

        splits = text.split(separator) if separator != "" else list(text)

        current_splits: List[str] = []
        join_sep = "" if separator == "" else separator

        for s in splits:
            if len(s) < self.chunk_size:
                current_splits.append(s)
            else:
                if current_splits:
                    merged = self._merge_splits(current_splits, join_sep)
                    final_pieces.extend(merged)
                    current_splits = []
                if not remaining_separators:
                    final_pieces.append(s)
                else:
                    sub_pieces = self._split_text(s, remaining_separators)
                    final_pieces.extend(sub_pieces)

        if current_splits:
            merged = self._merge_splits(current_splits, join_sep)
            final_pieces.extend(merged)

        return final_pieces

    def _merge_splits(self, splits: List[str], separator: str) -> List[str]:
        """Merges smaller pieces into chunks up to chunk_size with overlap."""
        docs: List[str] = []
        current_doc: List[str] = []
        total = 0

        for piece in splits:
            piece_len = len(piece) + (len(separator) if current_doc else 0)
            if total + piece_len > self.chunk_size:
                if total > 0:
                    doc_str = separator.join(current_doc).strip()
                    if doc_str:
                        docs.append(doc_str)
                    # Maintain overlap window
                    while total > self.chunk_overlap and current_doc:
                        popped = current_doc.pop(0)
                        total -= len(popped) + (len(separator) if current_doc else 0)
                current_doc.append(piece)
                total += len(piece) + (len(separator) if len(current_doc) > 1 else 0)
            else:
                current_doc.append(piece)
                total += piece_len

        if current_doc:
            doc_str = separator.join(current_doc).strip()
            if doc_str:
                docs.append(doc_str)

        return docs

    def split_document(self, document: Document) -> List[DocumentChunk]:
        """Splits a single Document into multiple chunks with metadata."""
        if not document.text or len(document.text.strip()) < 15:
            return []

        text_pieces = self._split_text(document.text, self.DEFAULT_SEPARATORS)
        chunks: List[DocumentChunk] = []
        source_name = document.metadata.get("source", "document")
        page_num = document.metadata.get("page", 1)

        for idx, piece in enumerate(text_pieces):
            piece = piece.strip()
            if len(piece) < 20:
                continue

            chunk_meta = dict(document.metadata)
            chunk_meta["chunk_index"] = idx
            chunk_meta["chunk_id"] = f"{source_name}_p{page_num}_c{idx}"
            chunk_meta["char_length"] = len(piece)

            chunks.append(DocumentChunk(text=piece, metadata=chunk_meta))

        return chunks

    def split_documents(self, documents: List[Document]) -> List[DocumentChunk]:
        """Splits a list of Documents into chunks."""
        all_chunks: List[DocumentChunk] = []
        for doc in documents:
            all_chunks.extend(self.split_document(doc))
        logger.info(f"Chunked {len(documents)} document pages into {len(all_chunks)} semantic chunks.")
        return all_chunks
