"""
End-to-End Document Ingestion Pipeline.
Coordinates file reading, semantic text chunking, vector embedding,
and registration in SQLite and ChromaDB.
"""

import time
from pathlib import Path
from typing import Dict, Any, Optional
from src.ingestion.document_loader import DocumentLoader
from src.ingestion.text_chunker import TextChunker
from src.retrieval.vector_store import ChromaVectorStore
from src.database.crud import register_document
from src.utils.logger import get_logger

logger = get_logger("IngestionPipeline")


class IngestionPipeline:
    """Master pipeline for ingesting university PDF/TXT documents."""

    def __init__(
        self,
        vector_store: Optional[ChromaVectorStore] = None,
        chunker: Optional[TextChunker] = None
    ):
        self.vector_store = vector_store or ChromaVectorStore()
        self.chunker = chunker or TextChunker()

    def ingest_file(self, file_path: Path) -> Dict[str, Any]:
        """
        Loads, chunks, embeds, and stores a document into ChromaDB and SQLite.
        
        Args:
            file_path: Path to the target PDF or TXT file.
            
        Returns:
            Dict containing ingestion status and metrics.
        """
        start_time = time.time()
        filename = file_path.name
        file_size = file_path.stat().st_size if file_path.exists() else 0

        logger.info(f"--- Starting Ingestion for: '{filename}' ({file_size} bytes) ---")

        try:
            # 1. Load Document
            documents = DocumentLoader.load_document(file_path)
            if not documents:
                return {
                    "success": False,
                    "filename": filename,
                    "error": "No readable text content could be extracted."
                }

            # 2. Chunk Text
            chunks = self.chunker.split_documents(documents)
            if not chunks:
                return {
                    "success": False,
                    "filename": filename,
                    "error": "Document produced 0 text chunks after length filtering."
                }

            # 3. Add to ChromaDB
            indexed_count = self.vector_store.add_chunks(chunks)

            # 4. Register in SQLite Database
            register_document(
                filename=filename,
                file_path=str(file_path),
                file_size_bytes=file_size,
                chunk_count=indexed_count
            )

            elapsed = round(time.time() - start_time, 2)
            logger.info(f"--- Ingestion Complete for '{filename}': {indexed_count} chunks indexed in {elapsed}s ---")

            return {
                "success": True,
                "filename": filename,
                "pages_loaded": len(documents),
                "chunks_indexed": indexed_count,
                "time_taken_seconds": elapsed
            }

        except Exception as e:
            logger.error(f"Ingestion failed for '{filename}': {e}", exc_info=True)
            return {
                "success": False,
                "filename": filename,
                "error": str(e)
            }
