"""
Document Loader Module for College Assistant.
Loads and extracts clean text and per-page metadata from PDF and TXT documents.
"""

from pathlib import Path
from typing import List, Dict, Any
import pypdf
from src.utils.helpers import clean_text
from src.utils.logger import get_logger

logger = get_logger("DocumentLoader")


class Document:
    """Represents an extracted document unit (a page or text section)."""
    def __init__(self, text: str, metadata: Dict[str, Any]):
        self.text = text
        self.metadata = metadata

    def __repr__(self):
        source = self.metadata.get("source", "unknown")
        page = self.metadata.get("page", 1)
        return f"<Document source='{source}' page={page} chars={len(self.text)}>"


class DocumentLoader:
    """Extracts text and page metadata from PDF and TXT files."""

    @classmethod
    def load_pdf(cls, file_path: Path) -> List[Document]:
        """
        Extracts text from PDF page-by-page.
        
        Args:
            file_path: Absolute or relative Path to PDF file.
            
        Returns:
            List[Document]: List of Document objects per page.
        """
        filename = file_path.name
        documents: List[Document] = []

        try:
            reader = pypdf.PdfReader(str(file_path))
            total_pages = len(reader.pages)
            logger.info(f"Loading PDF '{filename}' ({total_pages} pages)...")

            for page_idx, page in enumerate(reader.pages, start=1):
                try:
                    raw_text = page.extract_text() or ""
                    cleaned = clean_text(raw_text)
                    if cleaned:
                        meta = {
                            "source": filename,
                            "file_path": str(file_path),
                            "page": page_idx,
                            "total_pages": total_pages,
                            "file_type": "pdf"
                        }
                        documents.append(Document(text=cleaned, metadata=meta))
                except Exception as page_err:
                    logger.warning(f"Error extracting page {page_idx} of {filename}: {page_err}")

        except Exception as e:
            logger.error(f"Failed to read PDF file '{filename}': {e}")
            raise

        logger.info(f"Loaded {len(documents)} valid page(s) from '{filename}'.")
        return documents

    @classmethod
    def load_txt(cls, file_path: Path) -> List[Document]:
        """Loads plain text files."""
        filename = file_path.name
        try:
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    content = f.read()
            except UnicodeDecodeError:
                with open(file_path, "r", encoding="latin-1") as f:
                    content = f.read()

            cleaned = clean_text(content)
            if not cleaned:
                return []

            meta = {
                "source": filename,
                "file_path": str(file_path),
                "page": 1,
                "total_pages": 1,
                "file_type": "txt"
            }
            return [Document(text=cleaned, metadata=meta)]

        except Exception as e:
            logger.error(f"Failed to read TXT file '{filename}': {e}")
            raise

    @classmethod
    def load_document(cls, file_path: Path) -> List[Document]:
        """
        Dispatches loading based on file extension (.pdf or .txt).
        """
        ext = file_path.suffix.lower()
        if ext == ".pdf":
            return cls.load_pdf(file_path)
        elif ext in [".txt", ".md"]:
            return cls.load_txt(file_path)
        else:
            raise ValueError(f"Unsupported file format '{ext}'. Only .pdf and .txt are supported.")
