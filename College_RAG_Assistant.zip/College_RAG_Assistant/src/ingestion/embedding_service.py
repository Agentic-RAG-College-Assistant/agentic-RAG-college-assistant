"""
Embedding Service Module.
Uses HuggingFace Sentence Transformers to generate dense vector embeddings for text chunks.
"""

from typing import List, Optional
from sentence_transformers import SentenceTransformer
from src.config import Config
from src.utils.logger import get_logger

logger = get_logger("EmbeddingService")


class EmbeddingService:
    """Singleton-style service for generating dense text vector embeddings."""

    _instance: Optional["EmbeddingService"] = None

    def __new__(cls, model_name: Optional[str] = None):
        if cls._instance is None:
            cls._instance = super(EmbeddingService, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self, model_name: Optional[str] = None):
        if self._initialized:
            return

        self.model_name = model_name or Config.EMBEDDING_MODEL_NAME
        logger.info(f"Loading SentenceTransformer model '{self.model_name}'...")

        self.model = SentenceTransformer(self.model_name)
        # SentenceTransformers >= 2.5 uses get_sentence_embedding_dimension or get_embedding_dimension
        if hasattr(self.model, "get_sentence_embedding_dimension"):
            self._dim = self.model.get_sentence_embedding_dimension()
        else:
            self._dim = self.model.get_embedding_dimension()

        logger.info(f"Loaded '{self.model_name}' successfully. Vector dimension: {self._dim}")
        self._initialized = True

    @property
    def dimension(self) -> int:
        """Returns the embedding dimension (384 for all-MiniLM-L6-v2)."""
        return self._dim

    def embed_texts(self, texts: List[str]) -> List[List[float]]:
        """
        Generates embedding vectors for a batch of text chunks.
        Normalizes embeddings to unit length for cosine similarity.
        """
        if not texts:
            return []

        embeddings = self.model.encode(
            texts,
            batch_size=32,
            show_progress_bar=False,
            normalize_embeddings=True
        )
        return embeddings.tolist()

    def embed_query(self, query: str) -> List[float]:
        """Generates an embedding vector for a single search query."""
        embedding = self.model.encode(
            [query],
            show_progress_bar=False,
            normalize_embeddings=True
        )[0]
        return embedding.tolist()
