"""
Configuration Module for Agentic RAG College Assistant.
Loads environment variables and sets up project paths and constants.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Base Directory is the root of the project (College_RAG_Assistant)
BASE_DIR = Path(__file__).resolve().parent.parent

# Data Directories
DATA_DIR = BASE_DIR / "data"
DOCUMENTS_DIR = DATA_DIR / "documents"
UPLOADS_DIR = DATA_DIR / "uploads"
PROCESSED_DIR = DATA_DIR / "processed"

# Database & Vectorstore Directories
DATABASE_DIR = BASE_DIR / "database"
DATABASE_PATH = DATABASE_DIR / "college.db"

VECTORSTORE_DIR = BASE_DIR / "vectorstore"
CHROMA_DIR = VECTORSTORE_DIR / "chroma_db"

# Logs Directory
LOGS_DIR = BASE_DIR / "logs"

# Ensure all essential directories exist automatically
for folder in [DATA_DIR, DOCUMENTS_DIR, UPLOADS_DIR, PROCESSED_DIR, DATABASE_DIR, VECTORSTORE_DIR, CHROMA_DIR, LOGS_DIR]:
    folder.mkdir(parents=True, exist_ok=True)

# Load environment variables from .env
ENV_PATH = BASE_DIR / ".env"
if ENV_PATH.exists():
    load_dotenv(dotenv_path=ENV_PATH)
else:
    load_dotenv()


class Config:
    """Central configuration class."""

    # Project Information
    APP_NAME = "Agentic RAG College Assistant"
    APP_VERSION = "1.0.0"

    # Paths
    BASE_DIR = BASE_DIR
    DATA_DIR = DATA_DIR
    DOCUMENTS_DIR = DOCUMENTS_DIR
    UPLOADS_DIR = UPLOADS_DIR
    PROCESSED_DIR = PROCESSED_DIR
    DATABASE_PATH = DATABASE_PATH
    VECTORSTORE_DIR = VECTORSTORE_DIR
    CHROMA_DIR = CHROMA_DIR
    LOGS_DIR = LOGS_DIR

    # LLM Settings
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
    OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
    LLM_MODEL = os.getenv("LLM_MODEL", "gpt-3.5-turbo")
    LLM_TEMPERATURE = float(os.getenv("LLM_TEMPERATURE", "0.2"))
    LLM_MAX_TOKENS = int(os.getenv("LLM_MAX_TOKENS", "1000"))

    # Embeddings & ChromaDB Settings
    EMBEDDING_MODEL_NAME = os.getenv("EMBEDDING_MODEL_NAME", "all-MiniLM-L6-v2")
    CHROMA_COLLECTION_NAME = os.getenv("CHROMA_COLLECTION_NAME", "college_documents")

    # Document Chunking Settings
    CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", "700"))
    CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", "120"))

    # Retrieval Thresholds
    TOP_K_RESULTS = int(os.getenv("TOP_K_RESULTS", "4"))
    SIMILARITY_THRESHOLD = float(os.getenv("SIMILARITY_THRESHOLD", "0.30"))

    # Security & File Limits
    ALLOWED_EXTENSIONS = [".pdf", ".txt"]
    MAX_FILE_SIZE_MB = 25

    # Logging
    LOG_FILE = LOGS_DIR / "app.log"
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
