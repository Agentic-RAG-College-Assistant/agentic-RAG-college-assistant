"""
Admin Service Module.
Provides document ingestion management, knowledge base metrics,
file storage, and database administration tools for the Streamlit Admin Panel.
"""

from pathlib import Path
from typing import Dict, Any, List
from src.config import Config
from src.ingestion.ingestion_pipeline import IngestionPipeline
from src.retrieval.vector_store import ChromaVectorStore
from src.database import crud
from src.database.db import get_table_counts, init_db
from src.utils.logger import get_logger

logger = get_logger("AdminService")


class AdminService:
    """Manages document uploads, vector index maintenance, and database stats."""

    def __init__(self):
        self.vector_store = ChromaVectorStore()
        self.ingestion_pipeline = IngestionPipeline(vector_store=self.vector_store)

    def save_and_ingest(self, filename: str, file_bytes: bytes) -> Dict[str, Any]:
        """
        Saves an uploaded file to data/uploads and triggers the ingestion pipeline.
        """
        safe_filename = Path(filename).name
        target_path = Config.UPLOADS_DIR / safe_filename

        try:
            # Write bytes to disk
            with open(target_path, "wb") as f:
                f.write(file_bytes)
            logger.info(f"Saved uploaded file to {target_path}")

            # Run ingestion pipeline
            return self.ingestion_pipeline.ingest_file(target_path)

        except Exception as e:
            logger.error(f"Failed to process upload '{safe_filename}': {e}")
            return {"success": False, "filename": safe_filename, "error": str(e)}

    def ingest_sample_documents(self) -> Dict[str, Any]:
        """
        Indexes all files found in data/documents/.
        """
        docs = list(Config.DOCUMENTS_DIR.glob("*.*"))
        indexed = 0
        total_chunks = 0
        errors = []

        for doc_path in docs:
            if doc_path.suffix.lower() in Config.ALLOWED_EXTENSIONS:
                res = self.ingestion_pipeline.ingest_file(doc_path)
                if res.get("success"):
                    indexed += 1
                    total_chunks += res.get("chunks_indexed", 0)
                else:
                    errors.append(f"{doc_path.name}: {res.get('error')}")

        return {
            "total_files_found": len(docs),
            "files_indexed": indexed,
            "total_chunks_added": total_chunks,
            "errors": errors
        }

    def delete_document(self, filename: str) -> bool:
        """Removes a document from both ChromaDB and SQLite."""
        try:
            # 1. Remove from ChromaDB
            self.vector_store.delete_document(filename)

            # 2. Remove record from SQLite
            crud.delete_document_record(filename)

            # 3. Remove physical file if in uploads
            upload_path = Config.UPLOADS_DIR / filename
            if upload_path.exists():
                upload_path.unlink()

            logger.info(f"Document '{filename}' deleted from knowledge base.")
            return True
        except Exception as e:
            logger.error(f"Error deleting document '{filename}': {e}")
            return False

    def reset_knowledge_base(self) -> bool:
        """Clears ChromaDB collection and clears uploaded documents table."""
        try:
            self.vector_store.clear()
            logger.info("ChromaDB knowledge base cleared.")
            return True
        except Exception as e:
            logger.error(f"Error clearing knowledge base: {e}")
            return False

    def reset_database(self) -> bool:
        """Re-initializes and re-seeds the SQLite database."""
        try:
            init_db()
            crud.seed_database_if_empty()
            return True
        except Exception as e:
            logger.error(f"Error resetting SQLite database: {e}")
            return False

    def get_system_overview(self) -> Dict[str, Any]:
        """
        Returns high-level statistics for Admin Dashboard.
        """
        chroma_stats = self.vector_store.get_stats()
        sql_counts = get_table_counts()
        registered_docs = crud.get_all_registered_documents()

        return {
            "chroma_stats": chroma_stats,
            "sql_counts": sql_counts,
            "registered_documents": registered_docs
        }
