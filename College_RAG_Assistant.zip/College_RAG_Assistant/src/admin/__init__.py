"""Admin Service Package."""
